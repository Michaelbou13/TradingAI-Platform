const WebSocket = require('ws');
const { cache } = require('./marketData');
const { getActiveSignals } = require('./aiEngine');

let wss;
const clients = new Set();

function initWS(server) {
  wss = new WebSocket.Server({ server, path: '/ws' });
  wss.on('connection', ws => {
    clients.add(ws);
    ws.send(JSON.stringify({ type: 'init', prices: cache, signals: getActiveSignals(10) }));
    ws.on('close', () => clients.delete(ws));
    ws.on('error', () => clients.delete(ws));
  });
  setInterval(() => {
    const msg = JSON.stringify({ type: 'prices', data: cache, ts: Date.now() });
    clients.forEach(c => { if (c.readyState === WebSocket.OPEN) try { c.send(msg); } catch {} });
  }, 2000);
  setInterval(() => {
    const sigs = getActiveSignals(5);
    if (sigs.length) {
      const msg = JSON.stringify({ type: 'signals', data: sigs });
      clients.forEach(c => { if (c.readyState === WebSocket.OPEN) try { c.send(msg); } catch {} });
    }
  }, 30000);
}

module.exports = { initWS };
