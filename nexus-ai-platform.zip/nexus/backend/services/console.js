// ═══════════════════════════════════════════
//  NEXUS.ai — Console Management System
// ═══════════════════════════════════════════

const readline = require('readline');
const { getDB } = require('../config/database');
const { cache, getAllAssets, CRYPTO, STOCKS, FOREX } = require('./marketData');
const { getActiveSignals, scanMarkets } = require('./aiEngine');

const C = {
  reset: '\x1b[0m', bold: '\x1b[1m', dim: '\x1b[2m',
  red: '\x1b[31m', green: '\x1b[32m', yellow: '\x1b[33m',
  blue: '\x1b[34m', magenta: '\x1b[35m', cyan: '\x1b[36m', white: '\x1b[37m',
  bgBlue: '\x1b[44m', bgGreen: '\x1b[42m', bgRed: '\x1b[41m',
};

let rl;

function startConsole() {
  // Wait for server to boot, and only start if stdin is available
  setTimeout(() => {
    try {
      if (!process.stdin.readable && !process.stdin.isTTY) {
        console.log('[Console] Non-interactive mode — console disabled');
        return;
      }
      printBanner();
      createRL();
    } catch (e) {
      console.log('[Console] Could not start interactive console:', e.message);
    }
  }, 3000);
}

function createRL() {
  rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  prompt();
}

function prompt() {
  rl.question(`\n${C.blue}nexus${C.cyan}>${C.reset} `, (input) => {
    handleCommand(input.trim().toLowerCase());
  });
}

function printBanner() {
  console.log(`
${C.blue}═══════════════════════════════════════════════${C.reset}
${C.bold}  NEXUS.ai Console Management v2.0.0${C.reset}
${C.dim}  Type 'help' for available commands${C.reset}
${C.blue}═══════════════════════════════════════════════${C.reset}`);
}

async function handleCommand(cmd) {
  const [action, ...args] = cmd.split(' ');

  switch (action) {
    case 'help': case 'h': case '?':
      printHelp(); break;
    case 'status': case 'st':
      printStatus(); break;
    case 'users': case 'u':
      listUsers(args[0]); break;
    case 'markets': case 'm':
      printMarkets(args[0]); break;
    case 'prices': case 'p':
      printPrices(args[0]); break;
    case 'signals': case 'sig':
      printSignals(args[0]); break;
    case 'scan':
      await runScan(args[0], args[1]); break;
    case 'analyze': case 'a':
      await analyzeCmd(args[0]); break;
    case 'positions': case 'pos':
      printPositions(args[0]); break;
    case 'trades':
      printTrades(args[0]); break;
    case 'user':
      userDetail(args[0]); break;
    case 'adduser':
      addUser(args[0], args[1], args[2]); break;
    case 'setplan':
      setPlan(args[0], args[1]); break;
    case 'resetbalance': case 'rb':
      resetBalance(args[0], args[1]); break;
    case 'db':
      dbStats(); break;
    case 'config': case 'cfg':
      printConfig(); break;
    case 'clear': case 'cls':
      console.clear(); printBanner(); break;
    case 'exit': case 'quit': case 'q':
      console.log(`\n${C.yellow}Shutting down NEXUS.ai...${C.reset}\n`);
      process.exit(0);
    case '':
      break;
    default:
      console.log(`${C.red}Unknown command: ${action}${C.reset}  Type 'help' for commands.`);
  }
  prompt();
}

function printHelp() {
  console.log(`
${C.bold}${C.blue}═══ NEXUS.ai Console Commands ═══${C.reset}

${C.cyan}SYSTEM${C.reset}
  ${C.bold}status${C.reset}            Server status, uptime, connections
  ${C.bold}config${C.reset}            Show current configuration
  ${C.bold}db${C.reset}                Database statistics
  ${C.bold}clear${C.reset}             Clear console
  ${C.bold}exit${C.reset}              Shutdown server

${C.cyan}USERS${C.reset}
  ${C.bold}users${C.reset}             List all users
  ${C.bold}users ${C.dim}<limit>${C.reset}      List users with limit
  ${C.bold}user ${C.dim}<email>${C.reset}       User details
  ${C.bold}adduser ${C.dim}<email> <pass> <name>${C.reset}  Create user
  ${C.bold}setplan ${C.dim}<email> <plan>${C.reset}         Set plan (free/pro/elite)
  ${C.bold}resetbalance ${C.dim}<email> [amount]${C.reset}  Reset demo balance

${C.cyan}MARKETS${C.reset}
  ${C.bold}markets${C.reset}           Market overview (counts, status)
  ${C.bold}markets ${C.dim}<type>${C.reset}     Filter: crypto, stock, forex
  ${C.bold}prices${C.reset}            Top 20 prices
  ${C.bold}prices ${C.dim}<symbol>${C.reset}    Single asset price

${C.cyan}AI ENGINE${C.reset}
  ${C.bold}signals${C.reset}           Active AI signals
  ${C.bold}signals ${C.dim}<limit>${C.reset}    Show N signals
  ${C.bold}scan${C.reset}              Run full market scan
  ${C.bold}scan ${C.dim}<type>${C.reset}        Scan specific market
  ${C.bold}analyze ${C.dim}<symbol>${C.reset}   Deep AI analysis on asset

${C.cyan}TRADING${C.reset}
  ${C.bold}positions${C.reset}         All open positions
  ${C.bold}positions ${C.dim}<email>${C.reset}  User positions
  ${C.bold}trades${C.reset}            Recent closed trades
  ${C.bold}trades ${C.dim}<email>${C.reset}     User trade history
`);
}

function printStatus() {
  const uptime = process.uptime();
  const h = Math.floor(uptime / 3600);
  const m = Math.floor((uptime % 3600) / 60);
  const s = Math.floor(uptime % 60);

  const db = getDB();
  const userCount = db.prepare('SELECT COUNT(*) as c FROM users').get().c;
  const posCount = db.prepare("SELECT COUNT(*) as c FROM positions WHERE status='open'").get().c;
  const sigCount = db.prepare("SELECT COUNT(*) as c FROM ai_signals WHERE status='active'").get().c;
  const priceCount = Object.keys(cache).length;

  console.log(`
${C.blue}═══ Server Status ═══${C.reset}
  ${C.bold}Uptime${C.reset}           ${h}h ${m}m ${s}s
  ${C.bold}Node.js${C.reset}          ${process.version}
  ${C.bold}Memory${C.reset}           ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(1)} MB
  ${C.bold}Environment${C.reset}      ${process.env.NODE_ENV || 'development'}
  ${C.bold}Port${C.reset}             ${process.env.PORT || 4000}

${C.blue}═══ Data ═══${C.reset}
  ${C.bold}Users${C.reset}            ${userCount}
  ${C.bold}Live Prices${C.reset}      ${priceCount} assets
  ${C.bold}Open Positions${C.reset}   ${posCount}
  ${C.bold}Active Signals${C.reset}   ${sigCount}
  ${C.bold}Crypto Assets${C.reset}    ${Object.keys(CRYPTO).length}
  ${C.bold}Stock Assets${C.reset}     ${Object.keys(STOCKS).length}
  ${C.bold}Forex Pairs${C.reset}      ${Object.keys(FOREX).length}

${C.blue}═══ APIs ═══${C.reset}
  ${C.bold}CoinGecko${C.reset}        ${C.green}Active${C.reset} (free, no key)
  ${C.bold}Twelve Data${C.reset}      ${process.env.TWELVE_DATA_API_KEY ? `${C.green}Active${C.reset}` : `${C.yellow}No key — simulated${C.reset}`}
  ${C.bold}WebSocket${C.reset}        ${C.green}Active${C.reset}
`);
}

function listUsers(limit = 20) {
  const db = getDB();
  const users = db.prepare('SELECT id, email, name, plan, balance, created_at FROM users ORDER BY created_at DESC LIMIT ?').all(parseInt(limit) || 20);

  console.log(`\n${C.blue}═══ Users (${users.length}) ═══${C.reset}`);
  console.log(`  ${C.dim}${'EMAIL'.padEnd(28)} ${'NAME'.padEnd(18)} ${'PLAN'.padEnd(8)} ${'BALANCE'.padEnd(14)} JOINED${C.reset}`);
  users.forEach(u => {
    const planColor = u.plan === 'elite' ? C.magenta : u.plan === 'pro' ? C.cyan : C.dim;
    console.log(`  ${u.email.padEnd(28)} ${(u.name || '').padEnd(18)} ${planColor}${u.plan.padEnd(8)}${C.reset} $${u.balance.toLocaleString().padEnd(13)} ${u.created_at?.slice(0, 10) || '—'}`);
  });
}

function userDetail(email) {
  if (!email) { console.log(`${C.red}Usage: user <email>${C.reset}`); return; }
  const db = getDB();
  const u = db.prepare('SELECT * FROM users WHERE email=?').get(email);
  if (!u) { console.log(`${C.red}User not found: ${email}${C.reset}`); return; }

  const positions = db.prepare("SELECT COUNT(*) as c FROM positions WHERE user_id=? AND status='open'").get(u.id).c;
  const closed = db.prepare("SELECT COUNT(*) as c FROM positions WHERE user_id=? AND status='closed'").get(u.id).c;
  const scans = db.prepare("SELECT COUNT(*) as c FROM ai_scans WHERE user_id=?").get(u.id).c;

  console.log(`
${C.blue}═══ User: ${u.name} ═══${C.reset}
  ${C.bold}ID${C.reset}         ${u.id}
  ${C.bold}Email${C.reset}      ${u.email}
  ${C.bold}Plan${C.reset}       ${u.plan}
  ${C.bold}Balance${C.reset}    $${u.balance.toLocaleString()}
  ${C.bold}Risk${C.reset}       ${u.risk_level}
  ${C.bold}Positions${C.reset}  ${positions} open, ${closed} closed
  ${C.bold}AI Scans${C.reset}   ${scans}
  ${C.bold}Joined${C.reset}     ${u.created_at}
`);
}

function addUser(email, pass, name) {
  if (!email || !pass) { console.log(`${C.red}Usage: adduser <email> <password> <name>${C.reset}`); return; }
  try {
    const bcrypt = require('bcryptjs');
    const { v4: uuid } = require('uuid');
    const db = getDB();
    const id = uuid();
    db.prepare('INSERT INTO users (id,email,password_hash,name,plan,balance) VALUES (?,?,?,?,?,?)')
      .run(id, email, bcrypt.hashSync(pass, 10), name || email.split('@')[0], 'free', 100000);
    db.prepare('INSERT INTO user_settings (user_id) VALUES (?)').run(id);
    console.log(`${C.green}✓ Created user: ${email}${C.reset}`);
  } catch (e) { console.log(`${C.red}✗ ${e.message}${C.reset}`); }
}

function setPlan(email, plan) {
  if (!email || !plan) { console.log(`${C.red}Usage: setplan <email> <free|pro|elite>${C.reset}`); return; }
  if (!['free', 'pro', 'elite'].includes(plan)) { console.log(`${C.red}Plan must be: free, pro, or elite${C.reset}`); return; }
  try {
    const db = getDB();
    const r = db.prepare('UPDATE users SET plan=? WHERE email=?').run(plan, email);
    if (r.changes === 0) console.log(`${C.red}User not found${C.reset}`);
    else console.log(`${C.green}✓ ${email} → ${plan} plan${C.reset}`);
  } catch (e) { console.log(`${C.red}✗ ${e.message}${C.reset}`); }
}

function resetBalance(email, amount = '100000') {
  if (!email) { console.log(`${C.red}Usage: resetbalance <email> [amount]${C.reset}`); return; }
  try {
    const db = getDB();
    const r = db.prepare('UPDATE users SET balance=? WHERE email=?').run(parseFloat(amount), email);
    if (r.changes === 0) console.log(`${C.red}User not found${C.reset}`);
    else console.log(`${C.green}✓ ${email} balance → $${parseFloat(amount).toLocaleString()}${C.reset}`);
  } catch (e) { console.log(`${C.red}✗ ${e.message}${C.reset}`); }
}

function printMarkets(type) {
  const all = getAllAssets().filter(a => a.price);
  const filtered = type ? all.filter(a => a.type === type) : all;

  const crypto = all.filter(a => a.type === 'crypto');
  const stocks = all.filter(a => a.type === 'stock');
  const forex = all.filter(a => a.type === 'forex');

  console.log(`
${C.blue}═══ Market Overview ═══${C.reset}
  ${C.bold}Total Assets${C.reset}   ${all.length} with live prices
  ${C.bold}Crypto${C.reset}         ${crypto.length} / ${Object.keys(CRYPTO).length}
  ${C.bold}Stocks${C.reset}         ${stocks.length} / ${Object.keys(STOCKS).length}
  ${C.bold}Forex${C.reset}          ${forex.length} / ${Object.keys(FOREX).length}
`);

  if (type) {
    console.log(`  ${C.dim}${'SYM'.padEnd(10)} ${'NAME'.padEnd(20)} ${'PRICE'.padEnd(14)} CHANGE${C.reset}`);
    filtered.sort((a, b) => Math.abs(b.change_pct || 0) - Math.abs(a.change_pct || 0)).forEach(a => {
      const chgColor = (a.change_pct || 0) >= 0 ? C.green : C.red;
      console.log(`  ${a.symbol.padEnd(10)} ${(a.name || '').padEnd(20)} ${'$' + (a.price || 0).toLocaleString(undefined, { maximumFractionDigits: a.price > 100 ? 2 : 4 }).padEnd(13)} ${chgColor}${((a.change_pct || 0) >= 0 ? '+' : '') + (a.change_pct || 0).toFixed(2)}%${C.reset}`);
    });
  }
}

function printPrices(symbol) {
  if (symbol) {
    const sym = symbol.toUpperCase();
    const d = cache[sym];
    if (!d) { console.log(`${C.red}Asset not found: ${sym}${C.reset}`); return; }
    console.log(`\n  ${C.bold}${sym}${C.reset} — ${d.name || sym}`);
    console.log(`  Price:    $${d.price.toLocaleString(undefined, { maximumFractionDigits: 6 })}`);
    console.log(`  Change:   ${(d.change_pct || 0) >= 0 ? C.green + '+' : C.red}${(d.change_pct || 0).toFixed(2)}%${C.reset}`);
    console.log(`  Type:     ${d.type}`);
    if (d.volume) console.log(`  Volume:   $${(d.volume / 1e6).toFixed(1)}M`);
    if (d.market_cap) console.log(`  Mkt Cap:  $${(d.market_cap / 1e9).toFixed(1)}B`);
    return;
  }

  const all = Object.values(cache).filter(a => a.price).sort((a, b) => Math.abs(b.change_pct || 0) - Math.abs(a.change_pct || 0)).slice(0, 20);
  console.log(`\n${C.blue}═══ Top 20 Prices ═══${C.reset}`);
  console.log(`  ${C.dim}${'SYM'.padEnd(10)} ${'TYPE'.padEnd(8)} ${'PRICE'.padEnd(16)} CHANGE${C.reset}`);
  all.forEach(a => {
    const chgColor = (a.change_pct || 0) >= 0 ? C.green : C.red;
    console.log(`  ${a.symbol.padEnd(10)} ${(a.type || '').padEnd(8)} ${'$' + (a.price).toLocaleString(undefined, { maximumFractionDigits: a.price > 100 ? 2 : 4 }).padEnd(15)} ${chgColor}${((a.change_pct || 0) >= 0 ? '+' : '') + (a.change_pct || 0).toFixed(2)}%${C.reset}`);
  });
}

function printSignals(limit = 15) {
  const sigs = getActiveSignals(parseInt(limit) || 15);
  console.log(`\n${C.blue}═══ Active AI Signals (${sigs.length}) ═══${C.reset}`);
  if (sigs.length === 0) { console.log(`  ${C.dim}No active signals. Engine may still be warming up.${C.reset}`); return; }

  console.log(`  ${C.dim}${'SYM'.padEnd(10)} ${'TYPE'.padEnd(8)} ${'ACTION'.padEnd(8)} ${'CONF'.padEnd(6)} ${'TARGET'.padEnd(8)} ${'STOP'.padEnd(8)} R:R${C.reset}`);
  sigs.forEach(s => {
    const actColor = s.action === 'BUY' ? C.green : s.action === 'SELL' ? C.red : C.dim;
    console.log(`  ${s.symbol.padEnd(10)} ${(s.asset_type || '').padEnd(8)} ${actColor}${s.action.padEnd(8)}${C.reset} ${(s.confidence + '%').padEnd(6)} ${((s.target_pct > 0 ? '+' : '') + s.target_pct + '%').padEnd(8)} ${(s.stop_pct + '%').padEnd(8)} ${s.risk_reward}x`);
  });
}

async function runScan(type, minConf) {
  console.log(`\n${C.cyan}⚡ Running AI scan${type ? ' on ' + type : ''}...${C.reset}`);
  try {
    const results = await scanMarkets({ type: type || undefined, minConfidence: parseInt(minConf) || 65, limit: 20 });
    console.log(`${C.green}✓ Found ${results.length} signals${C.reset}\n`);
    console.log(`  ${C.dim}${'SYM'.padEnd(10)} ${'TYPE'.padEnd(8)} ${'ACTION'.padEnd(8)} ${'CONF'.padEnd(6)} SUMMARY${C.reset}`);
    results.forEach(r => {
      const actColor = r.action === 'BUY' ? C.green : r.action === 'SELL' ? C.red : C.dim;
      console.log(`  ${r.symbol.padEnd(10)} ${(r.asset_type || '').padEnd(8)} ${actColor}${r.action.padEnd(8)}${C.reset} ${(r.confidence + '%').padEnd(6)} ${(r.summary || '').slice(0, 60)}`);
    });
  } catch (e) { console.log(`${C.red}Scan failed: ${e.message}${C.reset}`); }
}

async function analyzeCmd(symbol) {
  if (!symbol) { console.log(`${C.red}Usage: analyze <symbol>${C.reset}`); return; }
  const sym = symbol.toUpperCase();
  console.log(`\n${C.cyan}⚡ Analyzing ${sym}...${C.reset}`);
  try {
    const { analyzeAsset } = require('./aiEngine');
    const result = await analyzeAsset(sym);
    if (!result) { console.log(`${C.red}No data for ${sym}${C.reset}`); return; }

    const actColor = result.action === 'BUY' ? C.green : result.action === 'SELL' ? C.red : C.dim;
    console.log(`
${C.blue}═══ AI Analysis: ${result.symbol} ═══${C.reset}
  ${C.bold}Name${C.reset}        ${result.name}
  ${C.bold}Type${C.reset}        ${result.asset_type}
  ${C.bold}Price${C.reset}       $${result.price.toLocaleString()}
  ${C.bold}Action${C.reset}      ${actColor}${C.bold}${result.action}${C.reset}
  ${C.bold}Confidence${C.reset}  ${result.confidence}%
  ${C.bold}Score${C.reset}       ${result.score > 0 ? C.green + '+' : C.red}${result.score}${C.reset}
  ${C.bold}Target${C.reset}      ${result.target_pct > 0 ? '+' : ''}${result.target_pct}%
  ${C.bold}Stop Loss${C.reset}   ${result.stop_pct}%
  ${C.bold}R:R${C.reset}         ${result.risk_reward}x

${C.blue}  Summary${C.reset}
  ${result.summary}

${C.blue}  Indicators${C.reset}
  RSI: ${result.indicators.rsi.toFixed(1)} | MACD: ${result.indicators.macd.toFixed(4)} | Stoch: ${result.indicators.stochastic.toFixed(1)}
  Trend: ${result.indicators.trend} | Momentum: ${result.indicators.momentum} | Volatility: ${result.indicators.volatility}

${C.blue}  Signal Breakdown${C.reset}`);
    result.signals.forEach(s => {
      const dot = s.includes('bullish') || s.includes('buy') || s.includes('oversold') || s.includes('above') || s.includes('positive') ? C.green + '●' : s.includes('bearish') || s.includes('overbought') || s.includes('below') || s.includes('negative') || s.includes('risk') ? C.red + '●' : C.dim + '●';
      console.log(`  ${dot}${C.reset} ${s}`);
    });
  } catch (e) { console.log(`${C.red}Analysis failed: ${e.message}${C.reset}`); }
}

function printPositions(email) {
  const db = getDB();
  let positions;
  if (email) {
    const u = db.prepare('SELECT id FROM users WHERE email=?').get(email);
    if (!u) { console.log(`${C.red}User not found${C.reset}`); return; }
    positions = db.prepare("SELECT p.*, u.email FROM positions p JOIN users u ON p.user_id=u.id WHERE p.user_id=? AND p.status='open' ORDER BY p.opened_at DESC").all(u.id);
  } else {
    positions = db.prepare("SELECT p.*, u.email FROM positions p JOIN users u ON p.user_id=u.id WHERE p.status='open' ORDER BY p.opened_at DESC LIMIT 50").all();
  }

  console.log(`\n${C.blue}═══ Open Positions (${positions.length}) ═══${C.reset}`);
  if (positions.length === 0) { console.log(`  ${C.dim}No open positions${C.reset}`); return; }

  console.log(`  ${C.dim}${'USER'.padEnd(22)} ${'SYM'.padEnd(10)} ${'SIDE'.padEnd(6)} ${'ENTRY'.padEnd(12)} ${'QTY'.padEnd(10)} CURRENT${C.reset}`);
  positions.forEach(p => {
    const cur = cache[p.symbol]?.price || p.entry_price;
    const pnl = p.side === 'long' ? (cur - p.entry_price) * p.quantity : (p.entry_price - cur) * p.quantity;
    const pnlColor = pnl >= 0 ? C.green : C.red;
    console.log(`  ${(p.email || '').padEnd(22)} ${p.symbol.padEnd(10)} ${p.side === 'long' ? C.green : C.red}${p.side.padEnd(6)}${C.reset} ${'$' + p.entry_price.toLocaleString().padEnd(11)} ${p.quantity.toFixed(4).padEnd(10)} $${cur.toLocaleString()} ${pnlColor}(${pnl >= 0 ? '+' : ''}$${pnl.toFixed(0)})${C.reset}`);
  });
}

function printTrades(email) {
  const db = getDB();
  let trades;
  if (email) {
    const u = db.prepare('SELECT id FROM users WHERE email=?').get(email);
    if (!u) { console.log(`${C.red}User not found${C.reset}`); return; }
    trades = db.prepare("SELECT p.*, u.email FROM positions p JOIN users u ON p.user_id=u.id WHERE p.user_id=? AND p.status='closed' ORDER BY p.closed_at DESC LIMIT 20").all(u.id);
  } else {
    trades = db.prepare("SELECT p.*, u.email FROM positions p JOIN users u ON p.user_id=u.id WHERE p.status='closed' ORDER BY p.closed_at DESC LIMIT 20").all();
  }

  console.log(`\n${C.blue}═══ Recent Trades (${trades.length}) ═══${C.reset}`);
  if (trades.length === 0) { console.log(`  ${C.dim}No closed trades${C.reset}`); return; }

  console.log(`  ${C.dim}${'USER'.padEnd(22)} ${'SYM'.padEnd(10)} ${'SIDE'.padEnd(6)} ${'ENTRY'.padEnd(12)} ${'EXIT'.padEnd(12)} P&L${C.reset}`);
  trades.forEach(t => {
    const pnlColor = (t.pnl || 0) >= 0 ? C.green : C.red;
    console.log(`  ${(t.email || '').padEnd(22)} ${t.symbol.padEnd(10)} ${t.side === 'long' ? C.green : C.red}${(t.side || '').padEnd(6)}${C.reset} ${'$' + (t.entry_price || 0).toLocaleString().padEnd(11)} ${'$' + (t.close_price || 0).toLocaleString().padEnd(11)} ${pnlColor}${(t.pnl || 0) >= 0 ? '+' : ''}$${(t.pnl || 0).toFixed(2)}${C.reset}`);
  });
}

function dbStats() {
  const db = getDB();
  console.log(`\n${C.blue}═══ Database Stats ═══${C.reset}`);
  const tables = ['users', 'positions', 'ai_signals', 'market_cache', 'ai_scans', 'user_settings', 'watchlist'];
  tables.forEach(t => {
    try {
      const count = db.prepare(`SELECT COUNT(*) as c FROM ${t}`).get().c;
      console.log(`  ${t.padEnd(20)} ${count} rows`);
    } catch { console.log(`  ${t.padEnd(20)} ${C.dim}—${C.reset}`); }
  });
}

function printConfig() {
  console.log(`
${C.blue}═══ Configuration ═══${C.reset}
  ${C.bold}PORT${C.reset}               ${process.env.PORT || 4000}
  ${C.bold}NODE_ENV${C.reset}           ${process.env.NODE_ENV || 'development'}
  ${C.bold}DB_PATH${C.reset}            ${process.env.DB_PATH || './data/nexus.db'}
  ${C.bold}JWT_SECRET${C.reset}         ${process.env.JWT_SECRET ? '****' + process.env.JWT_SECRET.slice(-4) : 'auto-generated'}
  ${C.bold}TWELVE_DATA_KEY${C.reset}    ${process.env.TWELVE_DATA_API_KEY ? '****' + process.env.TWELVE_DATA_API_KEY.slice(-4) : C.yellow + 'not set' + C.reset}
  ${C.bold}COINGECKO${C.reset}          ${C.green}free (no key needed)${C.reset}
`);
}

module.exports = { startConsole };
