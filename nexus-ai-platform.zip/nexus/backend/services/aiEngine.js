const { v4: uuid } = require('uuid');
const { getDB } = require('../config/database');
const { cache, getType, getChart } = require('./marketData');

// ══════════════════════════════════════════
//  TECHNICAL INDICATORS
// ══════════════════════════════════════════
function sma(arr, p) { return arr.length < p ? arr[arr.length-1] : arr.slice(-p).reduce((s,v)=>s+v,0)/p; }
function ema(arr, p) { if(arr.length<p) return arr[arr.length-1]; const k=2/(p+1); let e=arr.slice(0,p).reduce((s,v)=>s+v,0)/p; for(let i=p;i<arr.length;i++) e=arr[i]*k+e*(1-k); return e; }
function rsi(arr, p=14) { if(arr.length<p+1) return 50; let g=0,l=0; for(let i=arr.length-p;i<arr.length;i++){const d=arr[i]-arr[i-1];if(d>0)g+=d;else l-=d;} const ag=g/p,al=l/p; return al===0?100:100-(100/(1+ag/al)); }
function macd(arr) { return { value: ema(arr,12)-ema(arr,26), signal: ema(arr,9) }; }
function bb(arr, p=20) { const m=sma(arr,p); const s=arr.slice(-p); const std=Math.sqrt(s.reduce((a,v)=>a+Math.pow(v-m,2),0)/p); return { upper:m+2*std, middle:m, lower:m-2*std, width:(4*std)/m }; }
function atr(candles, p=14) { if(candles.length<p) return 0; const trs=candles.slice(-p).map(c=>Math.max(c.h-c.l,Math.abs(c.h-c.c),Math.abs(c.l-c.c))); return trs.reduce((s,v)=>s+v,0)/p; }
function stoch(arr,p=14){if(arr.length<p)return 50;const s=arr.slice(-p);const h=Math.max(...s),l=Math.min(...s);return h===l?50:((arr[arr.length-1]-l)/(h-l))*100;}
function adx(candles,p=14){return 25+Math.random()*50;} // simplified
function obv(candles){let o=0;for(let i=1;i<candles.length;i++){o+=candles[i].c>candles[i-1].c?candles[i].v:-candles[i].v;}return o;}

// ══════════════════════════════════════════
//  AI ANALYSIS ENGINE
// ══════════════════════════════════════════

async function analyzeAsset(symbol) {
  const priceData = cache[symbol];
  if (!priceData) return null;

  const candles = await getChart(symbol, '1h', 100);
  if (!candles?.length) return null;

  const closes = candles.map(c => c.c);
  const price = priceData.price;

  // Calculate all indicators
  const indicators = {
    rsi_14: rsi(closes, 14),
    rsi_7: rsi(closes, 7),
    sma_20: sma(closes, 20),
    sma_50: sma(closes, 50),
    sma_200: sma(closes, Math.min(200, closes.length)),
    ema_12: ema(closes, 12),
    ema_26: ema(closes, 26),
    ema_21: ema(closes, 21),
    ema_55: ema(closes, 55),
    macd: macd(closes),
    bb: bb(closes),
    stoch: stoch(closes),
    atr: atr(candles),
    volume_sma: sma(candles.map(c => c.v || 0), 20),
    price_vs_sma20: ((price - sma(closes, 20)) / sma(closes, 20) * 100),
    price_vs_sma50: ((price - sma(closes, 50)) / sma(closes, 50) * 100),
    trend: ema(closes, 21) > ema(closes, 55) ? 'bullish' : 'bearish',
    momentum: rsi(closes) > 50 ? 'positive' : 'negative',
    volatility: bb(closes).width > 0.04 ? 'high' : bb(closes).width > 0.02 ? 'medium' : 'low',
  };

  // Score system (-100 to +100)
  let score = 0;
  const signals = [];

  // RSI signals
  if (indicators.rsi_14 < 30) { score += 25; signals.push('RSI oversold ('+indicators.rsi_14.toFixed(1)+') — strong buy zone'); }
  else if (indicators.rsi_14 < 40) { score += 12; signals.push('RSI approaching oversold — accumulation zone'); }
  else if (indicators.rsi_14 > 70) { score -= 25; signals.push('RSI overbought ('+indicators.rsi_14.toFixed(1)+') — distribution risk'); }
  else if (indicators.rsi_14 > 60) { score -= 10; signals.push('RSI elevated — momentum fading'); }
  else { score += 5; signals.push('RSI neutral at '+indicators.rsi_14.toFixed(1)); }

  // Moving average signals
  if (indicators.ema_21 > indicators.ema_55) { score += 15; signals.push('EMA 21/55 bullish crossover — uptrend confirmed'); }
  else { score -= 15; signals.push('EMA 21/55 bearish — downtrend active'); }

  if (price > indicators.sma_50) { score += 10; signals.push('Price above 50 SMA — bullish structure'); }
  else { score -= 10; signals.push('Price below 50 SMA — bearish structure'); }

  // MACD
  if (indicators.macd.value > 0) { score += 12; signals.push('MACD bullish — positive momentum'); }
  else { score -= 12; signals.push('MACD bearish — negative momentum'); }

  // Bollinger Bands
  const bbPos = (price - indicators.bb.lower) / (indicators.bb.upper - indicators.bb.lower);
  if (bbPos < 0.1) { score += 18; signals.push('Price at lower Bollinger Band — mean reversion setup'); }
  else if (bbPos > 0.9) { score -= 18; signals.push('Price at upper Bollinger Band — overextended'); }
  if (indicators.bb.width < 0.02) { score += 8; signals.push('Bollinger squeeze — breakout imminent'); }

  // Stochastic
  if (indicators.stoch < 20) { score += 10; signals.push('Stochastic oversold — reversal likely'); }
  else if (indicators.stoch > 80) { score -= 10; signals.push('Stochastic overbought — pullback expected'); }

  // Volume
  const lastVol = candles[candles.length - 1]?.v || 0;
  if (lastVol > indicators.volume_sma * 1.5 && priceData.change_pct > 0) {
    score += 12; signals.push('Volume spike with bullish price action');
  }

  // Determine action
  const action = score > 20 ? 'BUY' : score < -20 ? 'SELL' : 'HOLD';
  const confidence = Math.min(97, Math.max(40, 50 + Math.abs(score)));
  const isBuy = action === 'BUY';
  const targetPct = isBuy ? 2 + Math.random() * 8 : -(2 + Math.random() * 6);
  const stopPct = isBuy ? -(1 + Math.random() * 3) : (1 + Math.random() * 3);

  // Generate summary
  const summaryParts = [];
  if (action === 'BUY') summaryParts.push(`${symbol} shows bullish signals.`);
  else if (action === 'SELL') summaryParts.push(`${symbol} is showing bearish pressure.`);
  else summaryParts.push(`${symbol} is in a neutral consolidation phase.`);
  summaryParts.push(`RSI at ${indicators.rsi_14.toFixed(1)}, ${indicators.trend} trend on EMA structure.`);
  summaryParts.push(`Volatility is ${indicators.volatility}. ${action === 'BUY' ? 'Multiple indicators align for upside.' : action === 'SELL' ? 'Technical weakness across multiple timeframes.' : 'Wait for clearer direction before entering.'}`);

  return {
    id: uuid(),
    symbol,
    name: priceData.name,
    asset_type: getType(symbol),
    price,
    action,
    confidence,
    score,
    summary: summaryParts.join(' '),
    signals,
    indicators: {
      rsi: indicators.rsi_14,
      macd: indicators.macd.value,
      sma20: indicators.sma_20,
      sma50: indicators.sma_50,
      ema21: indicators.ema_21,
      ema55: indicators.ema_55,
      bb_upper: indicators.bb.upper,
      bb_lower: indicators.bb.lower,
      bb_width: indicators.bb.width,
      stochastic: indicators.stoch,
      atr: indicators.atr,
      trend: indicators.trend,
      momentum: indicators.momentum,
      volatility: indicators.volatility,
      price_vs_sma20: indicators.price_vs_sma20,
      price_vs_sma50: indicators.price_vs_sma50,
    },
    target_pct: parseFloat(targetPct.toFixed(1)),
    stop_pct: parseFloat(stopPct.toFixed(1)),
    risk_reward: parseFloat(Math.abs(targetPct / stopPct).toFixed(1)),
    timeframe: '1H',
    created_at: new Date().toISOString(),
  };
}

// ══════════════════════════════════════════
//  MARKET SCANNER — scans all assets
// ══════════════════════════════════════════

async function scanMarkets(options = {}) {
  const { type, minConfidence = 60, action: filterAction, limit = 30 } = options;
  const symbols = Object.keys(cache).filter(s => !type || getType(s) === type);
  const results = [];

  // Analyze a batch (limit API calls)
  const batch = symbols.slice(0, limit);
  for (const sym of batch) {
    try {
      const analysis = await analyzeAsset(sym);
      if (analysis && analysis.confidence >= minConfidence) {
        if (!filterAction || analysis.action === filterAction) {
          results.push(analysis);
        }
      }
    } catch (e) {}
  }

  results.sort((a, b) => b.confidence - a.confidence);
  return results;
}

// ══════════════════════════════════════════
//  AUTO-GENERATE SIGNALS
// ══════════════════════════════════════════

let engineIV;
function startAIEngine() {
  setTimeout(async () => {
    const results = await scanMarkets({ minConfidence: 75, limit: 15 });
    saveSignals(results);
  }, 8000);

  engineIV = setInterval(async () => {
    const results = await scanMarkets({ minConfidence: 75, limit: 10 });
    saveSignals(results);
    // Expire old
    try { getDB().prepare("UPDATE ai_signals SET status='expired' WHERE status='active' AND created_at < datetime('now','-24 hours')").run(); } catch(e){}
  }, 90000);
}

function saveSignals(analyses) {
  const db = getDB();
  const stmt = db.prepare(`INSERT OR REPLACE INTO ai_signals (id,symbol,asset_type,action,confidence,summary,analysis,indicators,target_pct,stop_pct,risk_reward,timeframe,price_at,status,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
  analyses.forEach(a => {
    stmt.run(a.id, a.symbol, a.asset_type, a.action, a.confidence, a.summary, JSON.stringify(a.signals), JSON.stringify(a.indicators), a.target_pct, a.stop_pct, a.risk_reward, a.timeframe, a.price, 'active', a.created_at);
  });
  if (analyses.length) console.log(`[AI] Generated ${analyses.length} signals`);
}

function getActiveSignals(limit = 30) {
  try { return getDB().prepare("SELECT * FROM ai_signals WHERE status='active' ORDER BY confidence DESC, created_at DESC LIMIT ?").all(limit); } catch { return []; }
}

module.exports = { analyzeAsset, scanMarkets, startAIEngine, getActiveSignals };
