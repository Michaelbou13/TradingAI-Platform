const axios = require('axios');
const { getDB } = require('../config/database');

const TWELVE_KEY = () => process.env.TWELVE_DATA_API_KEY;

// ══════════════════════════════════════════
//  COMPLETE ASSET REGISTRY
// ══════════════════════════════════════════

const CRYPTO = {
  BTC:{cg:'bitcoin',name:'Bitcoin'},ETH:{cg:'ethereum',name:'Ethereum'},BNB:{cg:'binancecoin',name:'BNB'},
  SOL:{cg:'solana',name:'Solana'},XRP:{cg:'ripple',name:'XRP'},ADA:{cg:'cardano',name:'Cardano'},
  AVAX:{cg:'avalanche-2',name:'Avalanche'},DOT:{cg:'polkadot',name:'Polkadot'},
  MATIC:{cg:'matic-network',name:'Polygon'},LINK:{cg:'chainlink',name:'Chainlink'},
  UNI:{cg:'uniswap',name:'Uniswap'},ATOM:{cg:'cosmos',name:'Cosmos'},
  NEAR:{cg:'near',name:'NEAR'},APT:{cg:'aptos',name:'Aptos'},
  OP:{cg:'optimism',name:'Optimism'},ARB:{cg:'arbitrum',name:'Arbitrum'},
  FIL:{cg:'filecoin',name:'Filecoin'},LDO:{cg:'lido-dao',name:'Lido DAO'},
  INJ:{cg:'injective-protocol',name:'Injective'},TIA:{cg:'celestia',name:'Celestia'},
  DOGE:{cg:'dogecoin',name:'Dogecoin'},SHIB:{cg:'shiba-inu',name:'Shiba Inu'},
  PEPE:{cg:'pepe',name:'Pepe'},FET:{cg:'fetch-ai',name:'Fetch.ai'},
  RNDR:{cg:'render-token',name:'Render'},WLD:{cg:'worldcoin-wld',name:'Worldcoin'},
  JUP:{cg:'jupiter-exchange-solana',name:'Jupiter'},SUI:{cg:'sui',name:'Sui'},
  SEI:{cg:'sei-network',name:'Sei'},AAVE:{cg:'aave',name:'Aave'},
};

const STOCKS = {
  AAPL:{name:'Apple',base:247},MSFT:{name:'Microsoft',base:476},NVDA:{name:'NVIDIA',base:891},
  GOOG:{name:'Alphabet',base:192},AMZN:{name:'Amazon',base:224},META:{name:'Meta',base:585},
  TSLA:{name:'Tesla',base:311},AMD:{name:'AMD',base:178},NFLX:{name:'Netflix',base:892},
  CRM:{name:'Salesforce',base:312},ORCL:{name:'Oracle',base:168},AVGO:{name:'Broadcom',base:197},
  ADBE:{name:'Adobe',base:478},INTC:{name:'Intel',base:22},QCOM:{name:'Qualcomm',base:172},
  MU:{name:'Micron',base:98},PLTR:{name:'Palantir',base:72},SNOW:{name:'Snowflake',base:165},
  NET:{name:'Cloudflare',base:98},SHOP:{name:'Shopify',base:95},
  JPM:{name:'JPMorgan',base:243},GS:{name:'Goldman Sachs',base:512},V:{name:'Visa',base:312},
  MA:{name:'Mastercard',base:528},BAC:{name:'Bank of America',base:42},
  HD:{name:'Home Depot',base:385},WMT:{name:'Walmart',base:182},COST:{name:'Costco',base:892},
  NKE:{name:'Nike',base:78},DIS:{name:'Disney',base:118},PFE:{name:'Pfizer',base:28},
  JNJ:{name:'Johnson & Johnson',base:155},UNH:{name:'UnitedHealth',base:562},
  XOM:{name:'Exxon',base:112},CVX:{name:'Chevron',base:158},
  BA:{name:'Boeing',base:178},CAT:{name:'Caterpillar',base:372},LMT:{name:'Lockheed Martin',base:478},
  DE:{name:'Deere',base:392},GE:{name:'GE Aerospace',base:185},
  COIN:{name:'Coinbase',base:268},MSTR:{name:'MicroStrategy',base:1650},
};

const FOREX = {
  'EUR/USD':{name:'Euro / US Dollar',base:1.0845},'GBP/USD':{name:'British Pound / US Dollar',base:1.269},
  'USD/JPY':{name:'US Dollar / Japanese Yen',base:150.42},'AUD/USD':{name:'Australian Dollar / US Dollar',base:0.654},
  'USD/CAD':{name:'US Dollar / Canadian Dollar',base:1.361},'USD/CHF':{name:'US Dollar / Swiss Franc',base:0.883},
  'NZD/USD':{name:'New Zealand Dollar / US Dollar',base:0.613},'EUR/GBP':{name:'Euro / British Pound',base:0.855},
  'EUR/JPY':{name:'Euro / Japanese Yen',base:163.12},'GBP/JPY':{name:'British Pound / Japanese Yen',base:190.85},
  'AUD/JPY':{name:'Australian Dollar / Japanese Yen',base:98.37},'CAD/JPY':{name:'Canadian Dollar / Japanese Yen',base:110.52},
  'EUR/AUD':{name:'Euro / Australian Dollar',base:1.659},'GBP/AUD':{name:'British Pound / Australian Dollar',base:1.940},
  'EUR/CAD':{name:'Euro / Canadian Dollar',base:1.477},'GBP/CAD':{name:'British Pound / Canadian Dollar',base:1.729},
  'AUD/NZD':{name:'Australian Dollar / New Zealand Dollar',base:1.067},'EUR/NZD':{name:'Euro / New Zealand Dollar',base:1.769},
  'CHF/JPY':{name:'Swiss Franc / Japanese Yen',base:170.35},'USD/MXN':{name:'US Dollar / Mexican Peso',base:17.15},
};

let cache = {};

// ══════════════════════════════════════════
//  FETCH REAL DATA
// ══════════════════════════════════════════

async function fetchCrypto() {
  try {
    const ids = Object.values(CRYPTO).map(c => c.cg).join(',');
    const { data } = await axios.get(`https://api.coingecko.com/api/v3/simple/price?ids=${ids}&vs_currencies=usd&include_24hr_change=true&include_24hr_vol=true&include_market_cap=true`, { timeout: 12000 });
    const db = getDB();
    const stmt = db.prepare(`INSERT INTO market_cache (symbol,asset_type,name,price,change_pct,volume,market_cap,updated_at) VALUES (?,?,?,?,?,?,?,datetime('now')) ON CONFLICT(symbol) DO UPDATE SET price=excluded.price,change_pct=excluded.change_pct,volume=excluded.volume,market_cap=excluded.market_cap,updated_at=datetime('now')`);

    for (const [sym, info] of Object.entries(CRYPTO)) {
      const d = data[info.cg];
      if (d) {
        stmt.run(sym, 'crypto', info.name, d.usd, d.usd_24h_change || 0, d.usd_24h_vol || 0, d.usd_market_cap || 0);
        cache[sym] = { symbol: sym, name: info.name, type: 'crypto', price: d.usd, change_pct: d.usd_24h_change || 0, volume: d.usd_24h_vol || 0, market_cap: d.usd_market_cap || 0, ts: Date.now() };
      }
    }
    console.log('[MKT] Crypto prices updated');
  } catch (e) {
    console.error('[MKT] Crypto fetch error:', e.message);
    simCrypto();
  }
}

async function fetchStocks() {
  const key = TWELVE_KEY();
  if (!key) { simStocks(); return; }
  try {
    const syms = Object.keys(STOCKS).slice(0, 8).join(','); // free tier: batch 8 at a time
    const { data } = await axios.get(`https://api.twelvedata.com/quote?symbol=${syms}&apikey=${key}`, { timeout: 12000 });
    const db = getDB();
    const stmt = db.prepare(`INSERT INTO market_cache (symbol,asset_type,name,price,change_pct,volume,updated_at) VALUES (?,?,?,?,?,?,datetime('now')) ON CONFLICT(symbol) DO UPDATE SET price=excluded.price,change_pct=excluded.change_pct,volume=excluded.volume,updated_at=datetime('now')`);
    const quotes = Array.isArray(data) ? data : [data];
    quotes.forEach(q => {
      if (q?.close) {
        const s = STOCKS[q.symbol] || {};
        stmt.run(q.symbol, 'stock', s.name || q.symbol, parseFloat(q.close), parseFloat(q.percent_change || 0), parseInt(q.volume || 0));
        cache[q.symbol] = { symbol: q.symbol, name: s.name || q.symbol, type: 'stock', price: parseFloat(q.close), change_pct: parseFloat(q.percent_change || 0), volume: parseInt(q.volume || 0), ts: Date.now() };
      }
    });
    // Sim remaining
    Object.keys(STOCKS).filter(s => !cache[s]).forEach(sym => simAsset(sym, 'stock', STOCKS[sym]));
  } catch (e) {
    console.error('[MKT] Stock fetch error:', e.message);
    simStocks();
  }
}

async function fetchForex() {
  const key = TWELVE_KEY();
  if (!key) { simForex(); return; }
  try {
    const syms = Object.keys(FOREX).slice(0, 8).join(',');
    const { data } = await axios.get(`https://api.twelvedata.com/quote?symbol=${syms}&apikey=${key}`, { timeout: 12000 });
    const db = getDB();
    const stmt = db.prepare(`INSERT INTO market_cache (symbol,asset_type,name,price,change_pct,updated_at) VALUES (?,?,?,?,?,datetime('now')) ON CONFLICT(symbol) DO UPDATE SET price=excluded.price,change_pct=excluded.change_pct,updated_at=datetime('now')`);
    const quotes = Array.isArray(data) ? data : [data];
    quotes.forEach(q => {
      if (q?.close) {
        stmt.run(q.symbol, 'forex', FOREX[q.symbol]?.name || q.symbol, parseFloat(q.close), parseFloat(q.percent_change || 0));
        cache[q.symbol] = { symbol: q.symbol, name: FOREX[q.symbol]?.name || q.symbol, type: 'forex', price: parseFloat(q.close), change_pct: parseFloat(q.percent_change || 0), ts: Date.now() };
      }
    });
    Object.keys(FOREX).filter(s => !cache[s]).forEach(sym => simAsset(sym, 'forex', FOREX[sym]));
  } catch (e) {
    console.error('[MKT] Forex fetch error:', e.message);
    simForex();
  }
}

// ══════════════════════════════════════════
//  SIMULATION FALLBACKS
// ══════════════════════════════════════════

function simAsset(sym, type, info) {
  const prev = cache[sym];
  const base = info.base || (prev ? prev.price : 100);
  const price = prev ? prev.price + (Math.random() - 0.49) * base * (type === 'forex' ? 0.0003 : 0.002) : base;
  const chg = ((price - base) / base) * 100;
  cache[sym] = { symbol: sym, name: info.name, type, price, change_pct: chg, volume: Math.floor(Math.random() * 5e9), market_cap: type === 'crypto' ? price * 1e7 : 0, ts: Date.now() };
}

function simCrypto() {
  const bases = { BTC: 97420, ETH: 3580, BNB: 610, SOL: 186, XRP: 2.81, ADA: 0.72, AVAX: 42.5, DOT: 7.8, MATIC: 0.58, LINK: 19.5, UNI: 12.3, ATOM: 9.8, NEAR: 7.2, APT: 11.5, OP: 2.8, ARB: 1.45, FIL: 8.2, LDO: 2.1, INJ: 28, TIA: 12, DOGE: 0.18, SHIB: 0.000025, PEPE: 0.000018, FET: 2.4, RNDR: 9.8, WLD: 5.2, JUP: 1.1, SUI: 4.2, SEI: 0.58, AAVE: 320 };
  for (const [sym, info] of Object.entries(CRYPTO)) simAsset(sym, 'crypto', { ...info, base: bases[sym] || 10 });
}

function simStocks() { for (const [sym, info] of Object.entries(STOCKS)) simAsset(sym, 'stock', info); }
function simForex() { for (const [sym, info] of Object.entries(FOREX)) simAsset(sym, 'forex', info); }

// ══════════════════════════════════════════
//  CHART DATA
// ══════════════════════════════════════════

async function getChart(symbol, interval = '1h', limit = 120) {
  const type = getType(symbol);
  if (type === 'crypto') {
    try {
      const cgId = CRYPTO[symbol]?.cg;
      if (cgId) {
        const days = { '15m': 1, '1h': 3, '4h': 14, '1d': 90, '1w': 365 }[interval] || 3;
        const { data } = await axios.get(`https://api.coingecko.com/api/v3/coins/${cgId}/ohlc?vs_currency=usd&days=${days}`, { timeout: 10000 });
        if (data?.length) return data.map(([t, o, h, l, c]) => ({ t, o, h, l, c }));
      }
    } catch (e) {}
  }

  const key = TWELVE_KEY();
  if (key && type !== 'crypto') {
    try {
      const { data } = await axios.get(`https://api.twelvedata.com/time_series?symbol=${symbol}&interval=${interval}&outputsize=${limit}&apikey=${key}`, { timeout: 10000 });
      if (data?.values) return data.values.reverse().map(v => ({ t: new Date(v.datetime).getTime(), o: +v.open, h: +v.high, l: +v.low, c: +v.close, v: +v.volume || 0 }));
    } catch (e) {}
  }

  // Fallback: simulated candles
  const base = cache[symbol]?.price || 100;
  let p = base * 0.95;
  return Array.from({ length: limit }, (_, i) => {
    p += (Math.random() - 0.48) * base * 0.008;
    const o = p, c = o + (Math.random() - 0.48) * base * 0.006;
    return { t: Date.now() - (limit - i) * 3600000, o, c, h: Math.max(o, c) + Math.random() * base * 0.003, l: Math.min(o, c) - Math.random() * base * 0.003, v: Math.floor(Math.random() * 1e6) };
  });
}

function getType(sym) {
  if (CRYPTO[sym]) return 'crypto';
  if (FOREX[sym] || sym.includes('/')) return 'forex';
  return 'stock';
}

function getAllAssets() {
  const out = [];
  for (const [s, i] of Object.entries(CRYPTO)) out.push({ symbol: s, name: i.name, type: 'crypto', ...cache[s] });
  for (const [s, i] of Object.entries(STOCKS)) out.push({ symbol: s, name: i.name, type: 'stock', ...cache[s] });
  for (const [s, i] of Object.entries(FOREX)) out.push({ symbol: s, name: i.name, type: 'forex', ...cache[s] });
  return out;
}

let loopIV;
function startMarketLoop() {
  fetchCrypto(); fetchStocks(); fetchForex();
  loopIV = setInterval(() => { fetchCrypto(); fetchStocks(); fetchForex(); }, 30000);
}

module.exports = { cache, getAllAssets, getChart, getType, startMarketLoop, CRYPTO, STOCKS, FOREX };
