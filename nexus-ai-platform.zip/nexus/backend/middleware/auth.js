const jwt = require('jsonwebtoken');
const { getDB } = require('../config/database');
const SECRET = process.env.JWT_SECRET || require('crypto').randomBytes(32).toString('hex');

const genToken = (id) => jwt.sign({ id }, SECRET, { expiresIn: '7d' });

function auth(req, res, next) {
  const h = req.headers.authorization;
  if (!h?.startsWith('Bearer ')) return res.status(401).json({ error: true, message: 'Auth required' });
  try {
    const { id } = jwt.verify(h.split(' ')[1], SECRET);
    const user = getDB().prepare('SELECT id,email,name,plan,balance,risk_level,ai_scans_today,created_at FROM users WHERE id=?').get(id);
    if (!user) return res.status(401).json({ error: true, message: 'User not found' });
    req.user = user;
    next();
  } catch (e) {
    res.status(401).json({ error: true, message: e.name === 'TokenExpiredError' ? 'Token expired' : 'Invalid token' });
  }
}

module.exports = { auth, genToken, SECRET };
