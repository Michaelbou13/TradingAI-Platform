const r = require('express').Router();
const bcrypt = require('bcryptjs');
const { v4: uuid } = require('uuid');
const { body, validationResult } = require('express-validator');
const { getDB } = require('../config/database');
const { auth, genToken } = require('../middleware/auth');

r.post('/register', [body('email').isEmail(), body('password').isLength({min:6}), body('name').trim().isLength({min:1})], async (req, res) => {
  const errs = validationResult(req); if (!errs.isEmpty()) return res.status(400).json({ error: true, message: errs.array()[0].msg });
  try {
    const db = getDB(); const { email, password, name } = req.body;
    if (db.prepare('SELECT id FROM users WHERE email=?').get(email)) return res.status(409).json({ error: true, message: 'Email taken' });
    const id = uuid(); const hash = await bcrypt.hash(password, 12);
    db.prepare('INSERT INTO users (id,email,password_hash,name) VALUES (?,?,?,?)').run(id, email, hash, name);
    db.prepare('INSERT INTO user_settings (user_id) VALUES (?)').run(id);
    const user = db.prepare('SELECT id,email,name,plan,balance,created_at FROM users WHERE id=?').get(id);
    res.status(201).json({ user, token: genToken(id) });
  } catch (e) { res.status(500).json({ error: true, message: 'Registration failed' }); }
});

r.post('/login', [body('email').isEmail(), body('password').isLength({min:1})], async (req, res) => {
  const errs = validationResult(req); if (!errs.isEmpty()) return res.status(400).json({ error: true, message: 'Invalid credentials' });
  try {
    const db = getDB(); const user = db.prepare('SELECT * FROM users WHERE email=?').get(req.body.email);
    if (!user || !(await bcrypt.compare(req.body.password, user.password_hash))) return res.status(401).json({ error: true, message: 'Invalid email or password' });
    res.json({ user: { id: user.id, email: user.email, name: user.name, plan: user.plan, balance: user.balance, created_at: user.created_at }, token: genToken(user.id) });
  } catch (e) { res.status(500).json({ error: true, message: 'Login failed' }); }
});

r.get('/me', auth, (req, res) => res.json({ user: req.user }));

r.put('/profile', auth, (req, res) => {
  try {
    const db = getDB(); const { name, email } = req.body;
    if (name) db.prepare('UPDATE users SET name=? WHERE id=?').run(name, req.user.id);
    if (email) {
      if (db.prepare('SELECT id FROM users WHERE email=? AND id!=?').get(email, req.user.id)) return res.status(409).json({ error: true, message: 'Email taken' });
      db.prepare('UPDATE users SET email=? WHERE id=?').run(email, req.user.id);
    }
    res.json({ user: db.prepare('SELECT id,email,name,plan,balance,created_at FROM users WHERE id=?').get(req.user.id) });
  } catch (e) { res.status(500).json({ error: true, message: 'Update failed' }); }
});

module.exports = r;
