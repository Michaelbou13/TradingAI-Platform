const r = require('express').Router();
const { auth } = require('../middleware/auth');
const { analyzeAsset, scanMarkets, getActiveSignals } = require('../services/aiEngine');
const { getDB } = require('../config/database');
const { v4: uuid } = require('uuid');

// GET /api/ai/signals — active AI signals
r.get('/signals', auth, (req, res) => {
  let sigs = getActiveSignals(parseInt(req.query.limit) || 30);
  if (req.query.type) sigs = sigs.filter(s => s.asset_type === req.query.type);
  if (req.query.action) sigs = sigs.filter(s => s.action === req.query.action);
  if (req.query.minConf) sigs = sigs.filter(s => s.confidence >= parseInt(req.query.minConf));
  // Parse JSON fields
  sigs = sigs.map(s => ({ ...s, indicators: s.indicators ? JSON.parse(s.indicators) : {}, analysis: s.analysis ? JSON.parse(s.analysis) : [] }));
  res.json({ signals: sigs, count: sigs.length });
});

// GET /api/ai/analyze/:symbol — deep analysis on single asset
r.get('/analyze/:symbol', auth, async (req, res) => {
  try {
    const result = await analyzeAsset(req.params.symbol.toUpperCase());
    if (!result) return res.status(404).json({ error: true, message: 'Cannot analyze — no price data' });

    // Save scan record
    const db = getDB();
    db.prepare('INSERT INTO ai_scans (id,user_id,symbol,asset_type,result,created_at) VALUES (?,?,?,?,?,datetime("now"))')
      .run(uuid(), req.user.id, result.symbol, result.asset_type, JSON.stringify({ action: result.action, confidence: result.confidence }));

    res.json({ analysis: result });
  } catch (e) {
    console.error('[AI] Analyze error:', e);
    res.status(500).json({ error: true, message: 'Analysis failed' });
  }
});

// GET /api/ai/scan — scan markets for opportunities
r.get('/scan', auth, async (req, res) => {
  try {
    const results = await scanMarkets({
      type: req.query.type || undefined,
      minConfidence: parseInt(req.query.minConf) || 60,
      action: req.query.action || undefined,
      limit: parseInt(req.query.limit) || 20,
    });
    res.json({ results, count: results.length, scanned_at: new Date().toISOString() });
  } catch (e) {
    res.status(500).json({ error: true, message: 'Scan failed' });
  }
});

// GET /api/ai/stats — signal performance stats
r.get('/stats', auth, (req, res) => {
  try {
    const db = getDB();
    const total = db.prepare("SELECT COUNT(*) as c FROM ai_signals").get().c;
    const active = db.prepare("SELECT COUNT(*) as c FROM ai_signals WHERE status='active'").get().c;
    const buys = db.prepare("SELECT COUNT(*) as c FROM ai_signals WHERE action='BUY' AND status='active'").get().c;
    const sells = db.prepare("SELECT COUNT(*) as c FROM ai_signals WHERE action='SELL' AND status='active'").get().c;
    const avgConf = db.prepare("SELECT AVG(confidence) as v FROM ai_signals WHERE status='active'").get().v || 0;
    res.json({ total, active, buys, sells, holds: active - buys - sells, avgConfidence: avgConf.toFixed(1) });
  } catch (e) { res.status(500).json({ error: true, message: 'Stats failed' }); }
});

module.exports = r;
