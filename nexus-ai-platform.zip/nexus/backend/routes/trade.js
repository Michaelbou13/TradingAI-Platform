const r = require('express').Router();
const { v4: uuid } = require('uuid');
const { auth } = require('../middleware/auth');
const { getDB } = require('../config/database');
const { cache, getType } = require('../services/marketData');

// POST /api/trade/order — place demo order
r.post('/order', auth, (req, res) => {
  try {
    const db = getDB();
    const { symbol, side, amount, orderType = 'market', limitPrice, stopLoss, takeProfit } = req.body;
    const sym = symbol.toUpperCase();
    const pd = cache[sym];
    if (!pd) return res.status(400).json({ error: true, message: `Asset ${sym} not found` });
    const usd = parseFloat(amount);
    if (!usd || usd <= 0) return res.status(400).json({ error: true, message: 'Invalid amount' });
    if (!['long','short'].includes(side)) return res.status(400).json({ error: true, message: 'Side must be long or short' });

    const price = orderType === 'limit' && limitPrice ? parseFloat(limitPrice) : pd.price;
    const qty = usd / price;
    const fee = usd * 0.001;
    const total = usd + fee;

    const user = db.prepare('SELECT balance FROM users WHERE id=?').get(req.user.id);
    if (user.balance < total) return res.status(400).json({ error: true, message: `Insufficient balance. Need $${total.toFixed(2)}, have $${user.balance.toFixed(2)}` });

    const id = uuid();
    db.prepare('INSERT INTO positions (id,user_id,symbol,asset_type,name,side,entry_price,quantity,stop_loss,take_profit) VALUES (?,?,?,?,?,?,?,?,?,?)')
      .run(id, req.user.id, sym, getType(sym), pd.name || sym, side, price, qty, stopLoss || null, takeProfit || null);
    db.prepare('UPDATE users SET balance=balance-? WHERE id=?').run(total, req.user.id);

    res.status(201).json({
      position: { id, symbol: sym, side, entry_price: price, quantity: qty, fee },
      message: `${side.toUpperCase()} ${qty.toFixed(6)} ${sym} @ $${price.toLocaleString()} (demo)`
    });
  } catch (e) { console.error('[TRADE]', e); res.status(500).json({ error: true, message: 'Order failed' }); }
});

// POST /api/trade/close/:id
r.post('/close/:id', auth, (req, res) => {
  try {
    const db = getDB();
    const pos = db.prepare("SELECT * FROM positions WHERE id=? AND user_id=? AND status='open'").get(req.params.id, req.user.id);
    if (!pos) return res.status(404).json({ error: true, message: 'Position not found' });

    const pd = cache[pos.symbol];
    const closePrice = pd ? pd.price : pos.entry_price;
    const pnl = pos.side === 'long' ? (closePrice - pos.entry_price) * pos.quantity : (pos.entry_price - closePrice) * pos.quantity;
    const pnlPct = ((closePrice - pos.entry_price) / pos.entry_price) * 100 * (pos.side === 'long' ? 1 : -1);
    const proceeds = closePrice * pos.quantity * 0.999; // 0.1% fee

    db.prepare("UPDATE positions SET status='closed',close_price=?,pnl=?,pnl_pct=?,closed_at=datetime('now') WHERE id=?").run(closePrice, pnl, pnlPct, pos.id);
    db.prepare('UPDATE users SET balance=balance+? WHERE id=?').run(proceeds, req.user.id);

    res.json({ closed: { id: pos.id, symbol: pos.symbol, pnl: pnl.toFixed(2), pnl_pct: pnlPct.toFixed(2), close_price: closePrice } });
  } catch (e) { res.status(500).json({ error: true, message: 'Close failed' }); }
});

// GET /api/trade/orders — open positions
r.get('/orders', auth, (req, res) => {
  try {
    const db = getDB();
    const positions = db.prepare("SELECT * FROM positions WHERE user_id=? AND status='open' ORDER BY opened_at DESC").all(req.user.id);
    const enriched = positions.map(p => {
      const cur = cache[p.symbol]?.price || p.entry_price;
      const pnl = p.side === 'long' ? (cur - p.entry_price) * p.quantity : (p.entry_price - cur) * p.quantity;
      return { ...p, current_price: cur, pnl, pnl_pct: ((cur - p.entry_price) / p.entry_price) * 100 * (p.side === 'long' ? 1 : -1), value: cur * p.quantity };
    });
    res.json({ positions: enriched });
  } catch (e) { res.status(500).json({ error: true, message: 'Failed' }); }
});

module.exports = r;
