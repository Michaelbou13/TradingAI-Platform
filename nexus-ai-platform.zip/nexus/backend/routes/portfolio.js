const r = require('express').Router();
const { auth } = require('../middleware/auth');
const { getDB } = require('../config/database');
const { cache } = require('../services/marketData');

r.get('/', auth, (req, res) => {
  try {
    const db = getDB();
    const user = db.prepare('SELECT balance FROM users WHERE id=?').get(req.user.id);
    const positions = db.prepare("SELECT * FROM positions WHERE user_id=? AND status='open'").all(req.user.id);
    let totalValue = user.balance, totalPnl = 0;
    const enriched = positions.map(p => {
      const cur = cache[p.symbol]?.price || p.entry_price;
      const pnl = p.side === 'long' ? (cur - p.entry_price) * p.quantity : (p.entry_price - cur) * p.quantity;
      const val = cur * p.quantity;
      totalValue += val; totalPnl += pnl;
      return { ...p, current_price: cur, pnl, pnl_pct: ((cur - p.entry_price) / p.entry_price) * 100 * (p.side === 'long' ? 1 : -1), value: val };
    });
    const closed = db.prepare("SELECT * FROM positions WHERE user_id=? AND status='closed'").all(req.user.id);
    const wins = closed.filter(t => t.pnl > 0).length;
    const winRate = closed.length ? ((wins / closed.length) * 100).toFixed(1) : '0';
    const totalRealized = closed.reduce((s, t) => s + (t.pnl || 0), 0);

    res.json({ balance: user.balance, totalValue, totalPnl, positions: enriched, closedCount: closed.length, winRate: parseFloat(winRate), totalRealized });
  } catch (e) { res.status(500).json({ error: true, message: 'Failed' }); }
});

r.get('/history', auth, (req, res) => {
  try {
    const trades = getDB().prepare("SELECT * FROM positions WHERE user_id=? AND status='closed' ORDER BY closed_at DESC LIMIT ?").all(req.user.id, parseInt(req.query.limit) || 50);
    res.json({ trades });
  } catch (e) { res.status(500).json({ error: true, message: 'Failed' }); }
});

r.get('/performance', auth, (req, res) => {
  try {
    const closed = getDB().prepare("SELECT * FROM positions WHERE user_id=? AND status='closed' ORDER BY closed_at ASC").all(req.user.id);
    const pnls = closed.map(t => t.pnl || 0);
    const wins = pnls.filter(p => p > 0), losses = pnls.filter(p => p < 0);
    res.json({
      stats: {
        totalTrades: closed.length,
        winRate: closed.length ? ((wins.length / closed.length) * 100).toFixed(1) : 0,
        totalPnl: pnls.reduce((s, v) => s + v, 0).toFixed(2),
        avgWin: wins.length ? (wins.reduce((s, v) => s + v, 0) / wins.length).toFixed(2) : 0,
        avgLoss: losses.length ? (losses.reduce((s, v) => s + v, 0) / losses.length).toFixed(2) : 0,
        best: pnls.length ? Math.max(...pnls).toFixed(2) : 0,
        worst: pnls.length ? Math.min(...pnls).toFixed(2) : 0,
        profitFactor: losses.length ? Math.abs(wins.reduce((s, v) => s + v, 0) / losses.reduce((s, v) => s + v, 0)).toFixed(2) : 'N/A',
      }
    });
  } catch (e) { res.status(500).json({ error: true, message: 'Failed' }); }
});

module.exports = r;
