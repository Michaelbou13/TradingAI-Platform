const r = require('express').Router();
const { getAllAssets, cache, getChart, getType } = require('../services/marketData');

r.get('/prices', (req, res) => {
  let assets = getAllAssets();
  if (req.query.type) assets = assets.filter(a => a.type === req.query.type);
  if (req.query.q) { const q = req.query.q.toUpperCase(); assets = assets.filter(a => a.symbol.includes(q) || a.name?.toUpperCase().includes(q)); }
  res.json({ assets, count: assets.length });
});

r.get('/price/:symbol', (req, res) => {
  const d = cache[req.params.symbol.toUpperCase()];
  if (!d) return res.status(404).json({ error: true, message: 'Not found' });
  res.json(d);
});

r.get('/chart/:symbol', async (req, res) => {
  try {
    const data = await getChart(req.params.symbol.toUpperCase(), req.query.interval || '1h', parseInt(req.query.limit) || 120);
    res.json({ symbol: req.params.symbol.toUpperCase(), data });
  } catch (e) { res.status(500).json({ error: true, message: 'Chart fetch failed' }); }
});

r.get('/overview', (req, res) => {
  const all = getAllAssets().filter(a => a.price);
  const sorted = [...all].sort((a, b) => Math.abs(b.change_pct || 0) - Math.abs(a.change_pct || 0));
  res.json({
    total: all.length,
    crypto: all.filter(a => a.type === 'crypto').length,
    stocks: all.filter(a => a.type === 'stock').length,
    forex: all.filter(a => a.type === 'forex').length,
    topGainers: sorted.filter(a => (a.change_pct || 0) > 0).slice(0, 5),
    topLosers: sorted.filter(a => (a.change_pct || 0) < 0).slice(0, 5),
  });
});

module.exports = r;
