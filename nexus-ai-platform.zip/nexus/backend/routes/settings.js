const r = require('express').Router();
const { auth } = require('../middleware/auth');
const { getDB } = require('../config/database');

r.get('/', auth, (req, res) => {
  try {
    const db = getDB();
    const settings = db.prepare('SELECT * FROM user_settings WHERE user_id=?').get(req.user.id);
    res.json({ user: req.user, settings: settings || {} });
  } catch (e) { res.status(500).json({ error: true, message: 'Failed' }); }
});

r.put('/', auth, (req, res) => {
  try {
    const db = getDB();
    const { notify_email, notify_push, notify_sms, notify_discord, theme, currency } = req.body;
    db.prepare(`INSERT INTO user_settings (user_id,notify_email,notify_push,notify_sms,notify_discord,theme,currency) VALUES (?,?,?,?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET notify_email=excluded.notify_email,notify_push=excluded.notify_push,notify_sms=excluded.notify_sms,notify_discord=excluded.notify_discord,theme=excluded.theme,currency=excluded.currency`)
      .run(req.user.id, notify_email?1:0, notify_push?1:0, notify_sms?1:0, notify_discord?1:0, theme||'dark', currency||'USD');
    res.json({ message: 'Saved' });
  } catch (e) { res.status(500).json({ error: true, message: 'Failed' }); }
});

r.put('/risk', auth, (req, res) => {
  try {
    const { risk_level } = req.body;
    if (!['conservative','medium','aggressive'].includes(risk_level)) return res.status(400).json({ error: true, message: 'Invalid' });
    getDB().prepare('UPDATE users SET risk_level=? WHERE id=?').run(risk_level, req.user.id);
    res.json({ message: 'Updated' });
  } catch (e) { res.status(500).json({ error: true, message: 'Failed' }); }
});

module.exports = r;
