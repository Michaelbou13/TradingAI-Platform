const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');
const bcrypt = require('bcryptjs');
const { v4: uuid } = require('uuid');

const DB_PATH = process.env.DB_PATH || path.join(__dirname, '..', 'data', 'nexus.db');
let db;

function getDB() {
  if (!db) {
    fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
    db = new Database(DB_PATH);
    db.pragma('journal_mode = WAL');
    db.pragma('foreign_keys = ON');
  }
  return db;
}

async function initDB() {
  const d = getDB();
  d.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY, email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL,
      name TEXT NOT NULL, plan TEXT DEFAULT 'free', balance REAL DEFAULT 100000,
      risk_level TEXT DEFAULT 'medium', ai_scans_today INTEGER DEFAULT 0,
      created_at TEXT DEFAULT (datetime('now')), updated_at TEXT DEFAULT (datetime('now'))
    );
    CREATE TABLE IF NOT EXISTS user_settings (
      user_id TEXT PRIMARY KEY REFERENCES users(id),
      notify_email INTEGER DEFAULT 1, notify_push INTEGER DEFAULT 1,
      notify_sms INTEGER DEFAULT 0, notify_discord INTEGER DEFAULT 0,
      theme TEXT DEFAULT 'dark', currency TEXT DEFAULT 'USD'
    );
    CREATE TABLE IF NOT EXISTS watchlist (
      id TEXT PRIMARY KEY, user_id TEXT REFERENCES users(id),
      symbol TEXT NOT NULL, asset_type TEXT NOT NULL,
      UNIQUE(user_id, symbol)
    );
    CREATE TABLE IF NOT EXISTS positions (
      id TEXT PRIMARY KEY, user_id TEXT REFERENCES users(id),
      symbol TEXT NOT NULL, asset_type TEXT NOT NULL, name TEXT,
      side TEXT CHECK(side IN ('long','short')),
      entry_price REAL NOT NULL, quantity REAL NOT NULL,
      stop_loss REAL, take_profit REAL,
      status TEXT DEFAULT 'open' CHECK(status IN ('open','closed')),
      pnl REAL, pnl_pct REAL, close_price REAL,
      opened_at TEXT DEFAULT (datetime('now')), closed_at TEXT
    );
    CREATE TABLE IF NOT EXISTS ai_signals (
      id TEXT PRIMARY KEY, symbol TEXT NOT NULL, asset_type TEXT NOT NULL,
      action TEXT CHECK(action IN ('BUY','SELL','HOLD')),
      confidence REAL, summary TEXT, analysis TEXT,
      indicators TEXT, target_pct REAL, stop_pct REAL, risk_reward REAL,
      timeframe TEXT, price_at REAL,
      status TEXT DEFAULT 'active', created_at TEXT DEFAULT (datetime('now'))
    );
    CREATE TABLE IF NOT EXISTS market_cache (
      symbol TEXT PRIMARY KEY, asset_type TEXT, name TEXT,
      price REAL, change_pct REAL, volume REAL, market_cap REAL,
      high_24h REAL, low_24h REAL, updated_at TEXT DEFAULT (datetime('now'))
    );
    CREATE TABLE IF NOT EXISTS ai_scans (
      id TEXT PRIMARY KEY, user_id TEXT REFERENCES users(id),
      symbol TEXT, asset_type TEXT, result TEXT,
      created_at TEXT DEFAULT (datetime('now'))
    );
    CREATE INDEX IF NOT EXISTS idx_pos_user ON positions(user_id, status);
    CREATE INDEX IF NOT EXISTS idx_sig_status ON ai_signals(status, created_at);
  `);

  // Seed demo user if not exists
  const existing = d.prepare('SELECT id FROM users WHERE email=?').get('demo@nexus.ai');
  if (!existing) {
    const uid = uuid();
    d.prepare('INSERT INTO users (id,email,password_hash,name,plan,balance) VALUES (?,?,?,?,?,?)')
      .run(uid, 'demo@nexus.ai', bcrypt.hashSync('password123', 10), 'Demo Trader', 'pro', 100000);
    d.prepare('INSERT INTO user_settings (user_id) VALUES (?)').run(uid);

    // Seed positions
    [
      { sym: 'BTC', type: 'crypto', name: 'Bitcoin', side: 'long', entry: 94500, qty: 0.35 },
      { sym: 'ETH', type: 'crypto', name: 'Ethereum', side: 'long', entry: 3420, qty: 4.8 },
      { sym: 'NVDA', type: 'stock', name: 'NVIDIA', side: 'long', entry: 860, qty: 15 },
      { sym: 'EUR/USD', type: 'forex', name: 'EUR/USD', side: 'long', entry: 1.082, qty: 10000 },
      { sym: 'SOL', type: 'crypto', name: 'Solana', side: 'long', entry: 172, qty: 30 },
    ].forEach(p => {
      d.prepare('INSERT INTO positions (id,user_id,symbol,asset_type,name,side,entry_price,quantity) VALUES (?,?,?,?,?,?,?,?)')
        .run(uuid(), uid, p.sym, p.type, p.name, p.side, p.entry, p.qty);
    });

    // Seed watchlist
    ['BTC','ETH','SOL','NVDA','AAPL','TSLA','EUR/USD','GBP/USD'].forEach(sym => {
      const type = sym.includes('/') ? 'forex' : ['BTC','ETH','SOL','XRP','AVAX','DOT','MATIC','LINK','ADA','DOGE','BNB'].includes(sym) ? 'crypto' : 'stock';
      d.prepare('INSERT OR IGNORE INTO watchlist (id,user_id,symbol,asset_type) VALUES (?,?,?,?)').run(uuid(), uid, sym, type);
    });

    console.log('[DB] Seeded demo user: demo@nexus.ai / password123');
  }
  console.log('[DB] Ready');
}

if (require.main === module) {
  require('dotenv').config({ path: path.join(__dirname, '..', '.env') });
  initDB().then(() => { console.log('Done'); process.exit(0); });
}

module.exports = { getDB, initDB };
