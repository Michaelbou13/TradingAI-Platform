require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const compression = require('compression');
const http = require('http');
const path = require('path');
const rateLimit = require('express-rate-limit');
const { initDB } = require('./config/database');
const { initWS } = require('./services/websocket');
const { startMarketLoop } = require('./services/marketData');
const { startAIEngine } = require('./services/aiEngine');
const { startConsole } = require('./services/console');

const app = express();
const server = http.createServer(app);

app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: process.env.NODE_ENV === 'production' ? false : '*' }));
app.use(compression());
app.use(morgan('dev'));
app.use(express.json());
app.use(rateLimit({ windowMs: 60000, max: 200 }));

// Routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api/market', require('./routes/market'));
app.use('/api/ai', require('./routes/ai'));
app.use('/api/trade', require('./routes/trade'));
app.use('/api/portfolio', require('./routes/portfolio'));
app.use('/api/settings', require('./routes/settings'));

app.get('/api/health', (_, res) => res.json({ status: 'ok', time: new Date().toISOString() }));

// Serve frontend in prod
if (process.env.NODE_ENV === 'production') {
  app.use(express.static(path.join(__dirname, '..', 'frontend', 'dist')));
  app.get('*', (_, res) => res.sendFile(path.join(__dirname, '..', 'frontend', 'dist', 'index.html')));
}

app.use((err, req, res, next) => {
  console.error(err.message);
  res.status(err.status || 500).json({ error: true, message: err.message });
});

const PORT = process.env.PORT || 4000;

async function boot() {
  await initDB();
  initWS(server);
  startMarketLoop();
  startAIEngine();
  server.listen(PORT, () => {
    console.log(`\n⚡ NEXUS.ai Backend running on port ${PORT}`);
    console.log(`  Frontend: http://localhost:5173`);
    console.log(`  API:      http://localhost:${PORT}/api`);
    console.log(`  WS:       ws://localhost:${PORT}/ws\n`);
    startConsole();
  });
}

boot().catch(e => {
  console.error('\n══════════════════════════════════════════');
  console.error('  NEXUS.ai failed to start');
  console.error('══════════════════════════════════════════\n');
  console.error('Error:', e.message);
  console.error('');

  if (e.message && e.message.includes('better-sqlite3')) {
    console.error('FIX: better-sqlite3 needs native build tools.');
    console.error('  Windows: npm install --global windows-build-tools');
    console.error('  Mac:     xcode-select --install');
    console.error('  Linux:   sudo apt install build-essential python3');
    console.error('  Then re-run: cd backend && npm rebuild better-sqlite3');
  }

  if (e.message && e.message.includes('Cannot find module')) {
    console.error('FIX: Dependencies not installed.');
    console.error('  Run: cd backend && npm install');
  }

  console.error('\nServer will stay open so you can read this error.');
  console.error('Press Ctrl+C to exit.\n');

  // Keep process alive so the window doesn't close
  setInterval(() => {}, 60000);
});
