#!/usr/bin/env node

// ═══════════════════════════════════════════
//  NEXUS.ai — Startup Script
//  Run: node start.js
// ═══════════════════════════════════════════

const { execSync, spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

const ROOT = __dirname;
const BE = path.join(ROOT, 'backend');
const FE = path.join(ROOT, 'frontend');

function log(msg) { console.log(`  ${msg}`); }
function ok(msg) { console.log(`  [OK] ${msg}`); }
function err(msg) { console.log(`  [!!] ${msg}`); }
function header(msg) { console.log(`\n  === ${msg} ===`); }

function run(cmd, cwd) {
  try {
    execSync(cmd, { cwd, stdio: 'inherit', shell: true });
    return true;
  } catch (e) {
    return false;
  }
}

function exists(p) { return fs.existsSync(p); }

async function main() {
  console.log('');
  console.log('  ══════════════════════════════════════');
  console.log('  NEXUS.ai v2.0 — Startup');
  console.log('  ══════════════════════════════════════');
  console.log('');
  log(`Root: ${ROOT}`);
  log(`Node: ${process.version}`);
  console.log('');

  // ── Step 1: Root packages ──
  header('Step 1/5: Root packages');
  if (!exists(path.join(ROOT, 'node_modules', 'concurrently'))) {
    if (!run('npm install', ROOT)) {
      err('Root install failed. Run manually: npm install');
      process.exit(1);
    }
  }
  ok('Root packages ready');

  // ── Step 2: Backend packages ──
  header('Step 2/5: Backend packages');
  if (!exists(path.join(BE, 'node_modules', 'express'))) {
    log('Installing backend dependencies...');
    if (!run('npm install', BE)) {
      err('Backend install failed!');
      err(`Run manually: cd "${BE}" && npm install`);
      waitAndExit();
      return;
    }
  }
  // Verify
  if (!exists(path.join(BE, 'node_modules', 'express'))) {
    err('express not found after install!');
    err(`Run manually: cd "${BE}" && npm install`);
    waitAndExit();
    return;
  }
  ok('Backend packages ready');

  // ── Step 3: Frontend packages ──
  header('Step 3/5: Frontend packages');
  const viteBin = path.join(FE, 'node_modules', '.bin', process.platform === 'win32' ? 'vite.cmd' : 'vite');

  if (!exists(viteBin)) {
    log('Installing frontend dependencies...');
    // Clean any broken install
    const feModules = path.join(FE, 'node_modules');
    if (exists(feModules)) {
      log('Removing old node_modules...');
      try { fs.rmSync(feModules, { recursive: true, force: true }); } catch (e) {}
    }
    const lockFile = path.join(FE, 'package-lock.json');
    if (exists(lockFile)) {
      try { fs.unlinkSync(lockFile); } catch (e) {}
    }

    if (!run('npm install', FE)) {
      err('Frontend install failed!');
      log('Trying with --force...');
      if (!run('npm install --force', FE)) {
        err('Still failing.');
        err(`Run manually: cd "${FE}" && npm install`);
        err('If path is long, move nexus folder to C:\\nexus');
        waitAndExit();
        return;
      }
    }
  }

  if (!exists(viteBin)) {
    err('Vite binary not found after install!');
    err(`Expected at: ${viteBin}`);
    err(`Run manually: cd "${FE}" && npm install`);
    waitAndExit();
    return;
  }
  ok('Frontend packages ready');

  // ── Step 4: Config + DB ──
  header('Step 4/5: Config + Database');
  const envFile = path.join(BE, '.env');
  const envExample = path.join(BE, '.env.example');
  if (!exists(envFile) && exists(envExample)) {
    fs.copyFileSync(envExample, envFile);
    ok('Created .env');
  }

  run('node config/database.js init', BE);
  ok('Database ready');

  // ── Step 5: Launch ──
  header('Step 5/5: Launching');
  console.log('');
  console.log('  ══════════════════════════════════════');
  console.log('  Backend  : http://localhost:4000');
  console.log('  Frontend : http://localhost:5173');
  console.log('  Demo     : demo@nexus.ai / password123');
  console.log('  ══════════════════════════════════════');
  console.log('');
  log('Starting backend + frontend...');
  console.log('');

  // Start backend
  const backend = spawn('node', ['server.js'], {
    cwd: BE,
    stdio: 'inherit',
    shell: true,
  });

  // Wait 2s then start frontend
  await sleep(2000);

  const viteCmd = process.platform === 'win32' ? 'node_modules\\.bin\\vite.cmd' : 'node_modules/.bin/vite';
  const frontend = spawn(viteCmd, ['--host'], {
    cwd: FE,
    stdio: 'inherit',
    shell: true,
  });

  // Handle exit
  process.on('SIGINT', () => {
    log('Shutting down...');
    backend.kill();
    frontend.kill();
    process.exit(0);
  });

  backend.on('exit', (code) => {
    if (code !== 0 && code !== null) {
      err(`Backend exited with code ${code}`);
      frontend.kill();
    }
  });

  frontend.on('exit', (code) => {
    if (code !== 0 && code !== null) {
      err(`Frontend exited with code ${code}`);
    }
  });
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

function waitAndExit() {
  console.log('');
  log('Press Ctrl+C to exit.');
  // Keep alive so user can read errors
  setInterval(() => {}, 60000);
}

main().catch(e => {
  console.error('Startup error:', e);
  waitAndExit();
});
