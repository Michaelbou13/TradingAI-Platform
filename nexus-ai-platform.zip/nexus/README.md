# NEXUS.ai — AI-First Trading Intelligence Platform

A professional trading dashboard with AI-powered market scanning, analysis, and demo trading across **Crypto**, **Stocks**, and **Forex**. All trading uses demo money — no real funds at risk.

---

## What This Is

NEXUS.ai is a subscription-based AI trading intelligence platform. Users pay for access to:
- **AI Market Scanner** — scans 100+ assets in real-time, surfaces high-probability setups
- **AI Asset Analysis** — deep technical + sentiment analysis on any asset with actionable insights
- **Demo Trading** — paper trade with $100K demo balance to validate strategies
- **Professional Dashboard** — enterprise-grade charting, watchlists, portfolio tracking

This is NOT a broker. No real money. Educational + analytical tool.

---

## Tech Stack

| Layer       | Tech                                              |
|-------------|---------------------------------------------------|
| Frontend    | React 18, Vite, Tailwind CSS, Recharts, Zustand   |
| Backend     | Node.js, Express, WebSocket, JWT                   |
| Database    | SQLite (dev) / PostgreSQL (prod)                   |
| Market Data | CoinGecko (crypto free), Twelve Data (stocks/forex)|
| AI Engine   | Technical analysis pipeline (RSI, MACD, EMA, BB, patterns) |
| Deploy      | Docker Compose included                            |

---

## Quick Start

```bash
# 1. Install dependencies
npm run setup

# 2. Configure (optional — works without API keys using simulated data)
cp backend/.env.example backend/.env
# Add your free Twelve Data key for real stock/forex data: https://twelvedata.com

# 3. Initialize database
cd backend && npm run db:init && cd ..

# 4. Start everything
npm run dev
```

Open **http://localhost:5173** — Demo login: `demo@nexus.ai` / `password123`

---

## Supported Markets

### Crypto (30+ assets via CoinGecko — free, no key)
BTC, ETH, BNB, SOL, XRP, ADA, AVAX, DOT, MATIC, LINK, UNI, ATOM, NEAR, APT, OP, ARB, FIL, LDO, INJ, TIA, DOGE, SHIB, PEPE, FET, RNDR, WLD, JUP, PYTH, SEI, SUI

### Stocks (40+ via Twelve Data — free: 800 req/day)
AAPL, MSFT, NVDA, GOOG, AMZN, META, TSLA, AMD, NFLX, CRM, ORCL, AVGO, ADBE, INTC, QCOM, MU, DELL, PLTR, SNOW, NET, JPM, GS, V, MA, BAC, WFC, HD, WMT, COST, NKE, DIS, PFE, JNJ, UNH, XOM, CVX, BA, CAT, DE, LMT

### Forex (20+ pairs via Twelve Data)
EUR/USD, GBP/USD, USD/JPY, AUD/USD, USD/CAD, USD/CHF, NZD/USD, EUR/GBP, EUR/JPY, GBP/JPY, AUD/JPY, CAD/JPY, EUR/AUD, GBP/AUD, EUR/CAD, GBP/CAD, AUD/NZD, EUR/NZD, CHF/JPY, USD/MXN

---

## Pricing (what to charge users)

| Plan    | Price      | Includes                                          |
|---------|------------|---------------------------------------------------|
| Free    | $0         | 3 AI scans/day, basic dashboard, 5 watchlist slots |
| Pro     | $29/mo     | Unlimited scans, all markets, demo trading, alerts  |
| Elite   | $79/mo     | Everything + priority signals, custom screeners, API|

---

## Disclaimer

This platform is for **educational and analytical purposes only**. All trading uses simulated demo money. Past AI performance does not guarantee future results. This is not financial advice. Always do your own research before trading with real capital.

---

## License
MIT
