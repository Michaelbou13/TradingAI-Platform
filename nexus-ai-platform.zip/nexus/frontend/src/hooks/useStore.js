import { create } from 'zustand';
import { auth as authAPI, market as mktAPI, ai as aiAPI, portfolio as pfAPI } from '../utils/api';

const useStore = create((set, get) => ({
  user: JSON.parse(localStorage.getItem('nx_user') || 'null'),
  token: localStorage.getItem('nx_token'),
  loading: false, error: null,

  login: async (email, password) => {
    set({ loading: true, error: null });
    try {
      const { data } = await authAPI.login({ email, password });
      localStorage.setItem('nx_token', data.token); localStorage.setItem('nx_user', JSON.stringify(data.user));
      set({ user: data.user, token: data.token, loading: false }); return data;
    } catch (e) { const m = e.response?.data?.message || 'Login failed'; set({ loading: false, error: m }); throw new Error(m); }
  },
  register: async (name, email, password) => {
    set({ loading: true, error: null });
    try {
      const { data } = await authAPI.register({ name, email, password });
      localStorage.setItem('nx_token', data.token); localStorage.setItem('nx_user', JSON.stringify(data.user));
      set({ user: data.user, token: data.token, loading: false }); return data;
    } catch (e) { const m = e.response?.data?.message || 'Registration failed'; set({ loading: false, error: m }); throw new Error(m); }
  },
  logout: () => { localStorage.removeItem('nx_token'); localStorage.removeItem('nx_user'); set({ user: null, token: null, prices: {}, signals: [], portfolio: null }); },

  prices: {}, assets: [],
  fetchPrices: async (type) => {
    try { const { data } = await mktAPI.prices({ type }); const m = {}; data.assets.forEach(a => { m[a.symbol] = a; }); set({ prices: { ...get().prices, ...m }, assets: data.assets }); } catch {}
  },
  updatePrices: (p) => set({ prices: { ...get().prices, ...p } }),

  signals: [], signalsLoading: false,
  fetchSignals: async (p) => { set({ signalsLoading: true }); try { const { data } = await aiAPI.signals(p); set({ signals: data.signals, signalsLoading: false }); } catch { set({ signalsLoading: false }); } },

  portfolio: null,
  fetchPortfolio: async () => { try { const { data } = await pfAPI.summary(); set({ portfolio: data }); } catch {} },
}));

export default useStore;
