import { useEffect, useRef } from 'react';
import useStore from './useStore';

export default function useWS() {
  const ws = useRef(null);
  const retry = useRef(null);
  const update = useStore(s => s.updatePrices);

  useEffect(() => {
    function connect() {
      try {
        const url = `${location.protocol === 'https:' ? 'wss' : 'ws'}://${location.host}/ws`;
        ws.current = new WebSocket(url);
        ws.current.onmessage = e => {
          try {
            const m = JSON.parse(e.data);
            if (m.type === 'prices' && m.data) update(m.data);
            if (m.type === 'init' && m.prices) update(m.prices);
          } catch {}
        };
        ws.current.onclose = () => { retry.current = setTimeout(connect, 3000); };
        ws.current.onerror = () => ws.current?.close();
      } catch { retry.current = setTimeout(connect, 5000); }
    }
    connect();
    return () => { clearTimeout(retry.current); ws.current?.close(); };
  }, [update]);
}
