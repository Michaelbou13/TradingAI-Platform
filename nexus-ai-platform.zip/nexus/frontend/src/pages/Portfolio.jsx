import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import useStore from '../hooks/useStore';
import { trade as tradeAPI } from '../utils/api';

export default function Portfolio() {
  const { portfolio: p, fetchPortfolio } = useStore();
  useEffect(() => { fetchPortfolio(); }, []);
  const data = p || {};

  const handleClose = async id => {
    if (!confirm('Close this position?')) return;
    try { await tradeAPI.close(id); fetchPortfolio(); } catch (e) { alert(e.response?.data?.message || 'Failed'); }
  };

  return (
    <div className="flex flex-col gap-4">
      <h1 className="text-lg font-extrabold tracking-tight">Portfolio <span className="text-[10px] text-amber-400 font-normal ml-2">DEMO</span></h1>
      <div className="grid grid-cols-5 gap-2">
        {[{l:'Total Value',v:`$${(data.totalValue||100000).toLocaleString(undefined,{maximumFractionDigits:0})}`,c:'text-white'},{l:'P&L',v:`${(data.totalPnl||0)>=0?'+':''}$${(data.totalPnl||0).toLocaleString(undefined,{maximumFractionDigits:0})}`,c:(data.totalPnl||0)>=0?'text-emerald-400':'text-red-400'},{l:'Cash',v:`$${(data.balance||0).toLocaleString(undefined,{maximumFractionDigits:0})}`,c:'text-blue-400'},{l:'Win Rate',v:`${data.winRate||0}%`,c:'text-emerald-400'},{l:'Realized',v:`$${(data.totalRealized||0).toLocaleString(undefined,{maximumFractionDigits:0})}`,c:'text-white'}].map(s=>(
          <div key={s.l} className="bg-bg-2 border border-white/[.06] rounded-xl p-3"><div className="text-[8px] text-slate-500 tracking-widest uppercase font-semibold mb-1">{s.l}</div><div className={`text-lg font-bold font-mono ${s.c}`}>{s.v}</div></div>
        ))}
      </div>
      <div className="bg-bg-2 border border-white/[.06] rounded-xl overflow-hidden">
        <div className="flex justify-between items-center px-4 py-2.5 border-b border-white/[.04]"><span className="text-sm font-bold">Open Positions ({(data.positions||[]).length})</span><Link to="/app/trade" className="text-[10px] text-brand">New Trade →</Link></div>
        <div className="grid grid-cols-9 gap-1 px-4 py-1.5 text-[8px] font-semibold text-slate-500 tracking-widest uppercase border-b border-white/[.04]"><span>Asset</span><span>Type</span><span>Side</span><span>Entry</span><span>Current</span><span>Qty</span><span>Value</span><span>P&L</span><span></span></div>
        {(data.positions||[]).length===0?<div className="p-10 text-center text-xs text-slate-500">No open positions. <Link to="/app/trade" className="text-brand">Start trading →</Link></div>:(data.positions||[]).map(pos=>(
          <div key={pos.id} className="grid grid-cols-9 gap-1 px-4 py-2.5 border-b border-white/[.02] items-center">
            <Link to={`/app/analyze/${pos.symbol}`} className="text-[11px] font-bold font-mono text-brand hover:underline">{pos.symbol}</Link>
            <span className="text-[9px] text-slate-400 capitalize">{pos.asset_type}</span>
            <span className={`text-[8px] font-bold px-1.5 py-0.5 rounded w-fit ${pos.side==='long'?'bg-emerald-500/10 text-emerald-400':'bg-red-500/10 text-red-400'}`}>{pos.side.toUpperCase()}</span>
            <span className="text-[10px] text-slate-400 font-mono">${pos.entry_price}</span>
            <span className="text-[10px] text-white font-mono">${(pos.current_price||0).toLocaleString(undefined,{maximumFractionDigits:2})}</span>
            <span className="text-[10px] text-slate-400 font-mono">{(pos.quantity||0).toFixed(4)}</span>
            <span className="text-[10px] text-white font-mono">${(pos.value||0).toLocaleString(undefined,{maximumFractionDigits:0})}</span>
            <span className={`text-[10px] font-bold font-mono ${(pos.pnl||0)>=0?'text-emerald-400':'text-red-400'}`}>{(pos.pnl||0)>=0?'+':''}${(pos.pnl||0).toFixed(0)} <span className="text-[8px] opacity-60">({(pos.pnl_pct||0).toFixed(1)}%)</span></span>
            <button onClick={()=>handleClose(pos.id)} className="text-[10px] text-red-400 border border-red-400/20 bg-red-400/5 px-2.5 py-1 rounded hover:bg-red-400/10">Close</button>
          </div>
        ))}
      </div>
    </div>
  );
}
