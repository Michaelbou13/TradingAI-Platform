import { Link } from 'react-router-dom';
import { useState } from 'react';
import { Zap, BarChart3, Brain, Shield, Bot, Bell, BookOpen, AlertTriangle } from 'lucide-react';

export default function Landing() {
  const [annual, setAnnual] = useState(true);

  return (
    <div className="min-h-screen bg-bg text-slate-200 font-sans">
      {/* Nav */}
      <nav className="fixed top-0 inset-x-0 z-50 bg-bg/90 backdrop-blur-xl border-b border-white/[.04]">
        <div className="max-w-6xl mx-auto px-6 flex items-center justify-between h-14">
          <div className="flex items-center gap-2"><div className="w-7 h-7 bg-brand rounded-lg flex items-center justify-center"><Zap size={14} className="text-white" /></div><span className="text-sm font-extrabold">NEXUS<span className="text-brand">.ai</span></span></div>
          <div className="flex items-center gap-5">
            <a href="#features" className="text-xs text-slate-400">Features</a>
            <a href="#pricing" className="text-xs text-slate-400">Pricing</a>
            <Link to="/login" className="text-xs text-slate-400 border border-white/10 px-3.5 py-1.5 rounded-lg">Sign In</Link>
            <Link to="/signup" className="text-xs font-semibold bg-brand text-white px-4 py-1.5 rounded-lg shadow-lg shadow-brand/25">Get Started Free</Link>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="min-h-screen flex items-center px-6 pt-20 relative">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_60%_40%_at_50%_35%,rgba(59,130,246,.06),transparent_60%)]" />
        <div className="max-w-6xl mx-auto relative z-10">
          <div className="max-w-xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-brand/10 border border-brand/15 rounded-full mb-5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" style={{animation:'pulse 2s infinite'}} />
              <span className="text-[10px] text-brand font-semibold tracking-widest uppercase">Scanning 90+ Markets Live</span>
            </div>
            <h1 className="text-5xl font-extrabold leading-[1.08] tracking-tight mb-4">
              Your AI<br />Trading Edge<span className="text-brand">.</span>
            </h1>
            <p className="text-sm text-slate-400 leading-relaxed max-w-md mb-7">
              AI-powered market scanning, technical analysis, and trade signals across crypto, stocks, and forex. Practice with demo money. Learn with real data.
            </p>
            <div className="flex gap-3">
              <Link to="/signup" className="px-6 py-3 bg-brand text-white text-sm font-bold rounded-xl shadow-lg shadow-brand/25">Start Free — 14 Days →</Link>
              <Link to="/login" className="px-6 py-3 bg-white/[.03] border border-white/10 text-slate-300 text-sm font-semibold rounded-xl">Demo Account</Link>
            </div>
            <p className="text-[10px] text-slate-600 mt-3">No credit card required. $100K demo balance included.</p>
          </div>
        </div>
      </section>

      {/* Disclaimer Banner */}
      <section className="px-6 pb-10">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-start gap-3 p-4 bg-amber-500/[.04] border border-amber-500/10 rounded-xl">
            <AlertTriangle size={16} className="text-amber-400 mt-0.5 flex-shrink-0" />
            <div>
              <div className="text-xs font-bold text-amber-400 mb-1">Educational Platform — No Real Money</div>
              <div className="text-[11px] text-slate-400 leading-relaxed">NEXUS.ai is an educational and analytical tool. All trading uses simulated demo funds. AI analysis is for informational purposes only and does not constitute financial advice. Past performance does not guarantee future results. Always do your own research before making investment decisions with real capital.</div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="px-6 pb-12">
        <div className="max-w-6xl mx-auto grid grid-cols-4 gap-px bg-white/[.06] rounded-xl overflow-hidden">
          {[{n:'90+',l:'Assets Tracked',d:'Crypto, stocks & forex'},{n:'12',l:'AI Indicators',d:'RSI, MACD, BB, EMA, ATR...'},{n:'Real-Time',l:'Market Data',d:'CoinGecko + Twelve Data'},{n:'$100K',l:'Demo Balance',d:'Practice risk-free'}].map((s,i)=>(
            <div key={i} className="bg-bg-2 px-6 py-6"><div className="text-xl font-extrabold font-mono">{s.n}</div><div className="text-[10px] font-semibold text-brand mt-1">{s.l}</div><div className="text-[10px] text-slate-500 mt-0.5">{s.d}</div></div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section id="features" className="px-6 py-14">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-10"><p className="text-[10px] text-brand tracking-[3px] uppercase font-bold mb-1.5">Platform</p><h2 className="text-3xl font-extrabold tracking-tight">AI-first trading intelligence.</h2></div>
          <div className="grid grid-cols-3 gap-3">
            {[
              {icon:Brain,title:'AI Market Scanner',desc:'Scans all 90+ assets simultaneously. Surfaces high-probability setups ranked by confidence score. Your AI analyst, working 24/7.'},
              {icon:BarChart3,title:'Deep Technical Analysis',desc:'12 indicators per asset: RSI, MACD, Bollinger Bands, EMA crossovers, Stochastic, ATR, volume analysis, and trend detection.'},
              {icon:Zap,title:'Real-Time Signals',desc:'AI generates BUY/SELL/HOLD signals with confidence scores, target prices, stop-losses, and risk:reward ratios.'},
              {icon:Shield,title:'Risk Management',desc:'AI-calculated position sizing, portfolio risk scoring, and automatic stop-loss suggestions based on your risk tolerance.'},
              {icon:Bot,title:'Demo Trading',desc:'Practice strategies with $100K demo balance. Execute trades, track P&L, build your track record — all risk-free.'},
              {icon:BookOpen,title:'Learn By Doing',desc:'Every AI signal comes with a plain-English explanation of why. Understand the technicals behind every trade.'},
            ].map((f,i)=>(<div key={i} className="bg-bg-2 border border-white/[.06] rounded-xl p-5"><f.icon size={22} className="text-brand mb-3" /><h3 className="text-sm font-bold mb-1.5">{f.title}</h3><p className="text-xs text-slate-400 leading-relaxed">{f.desc}</p></div>))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="px-6 py-14">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8"><p className="text-[10px] text-brand tracking-[3px] uppercase font-bold mb-1.5">Pricing</p><h2 className="text-3xl font-extrabold tracking-tight mb-2">Affordable intelligence.</h2><p className="text-xs text-slate-400 max-w-sm mx-auto mb-5">14-day free trial. Cancel anytime. No hidden fees.</p>
            <div className="inline-flex bg-bg-3 rounded-lg p-0.5">
              <button onClick={()=>setAnnual(false)} className={`px-4 py-1.5 rounded-md text-xs font-semibold ${!annual?'bg-bg-5 text-white':'text-slate-500'}`}>Monthly</button>
              <button onClick={()=>setAnnual(true)} className={`px-4 py-1.5 rounded-md text-xs font-semibold ${annual?'bg-bg-5 text-white':'text-slate-500'}`}>Annual <span className="text-emerald-400">-30%</span></button>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-3">
            {[
              {name:'Free',price:0,desc:'Get started',features:['3 AI scans/day','Basic dashboard','5 watchlist slots','Demo trading','Community']},
              {name:'Pro',price:annual?29:39,desc:'For active traders',pop:true,features:['Unlimited AI scans','Full analysis dashboard','All 90+ markets','Demo trading + history','Real-time alerts','Priority signals','API access']},
              {name:'Elite',price:annual?79:109,desc:'For professionals',features:['Everything in Pro','Custom AI screeners','Advanced risk tools','Export data & reports','Priority support','Early feature access','White-glove setup']},
            ].map((p,i)=>(<div key={i} className={`bg-bg-2 rounded-xl p-6 flex flex-col border relative overflow-hidden ${p.pop?'border-brand/25':'border-white/[.06]'}`}>
              {p.pop&&<div className="absolute top-0 inset-x-0 h-0.5 bg-gradient-to-r from-transparent via-brand to-transparent" />}
              <div className="text-[10px] text-brand tracking-widest uppercase font-bold mb-0.5">{p.name}</div>
              <div className="text-[10px] text-slate-500 mb-3">{p.desc}</div>
              <div className="flex items-baseline gap-1 mb-5">{p.price===0?<span className="text-3xl font-extrabold">Free</span>:<><span className="text-3xl font-extrabold font-mono">${p.price}</span><span className="text-xs text-slate-500">/mo</span></>}</div>
              <div className="flex-1">{p.features.map((f,j)=>(<div key={j} className="flex items-center gap-2 py-1"><span className="text-emerald-400 text-[10px]">✓</span><span className="text-xs text-slate-300">{f}</span></div>))}</div>
              <Link to="/signup" className={`mt-4 block text-center py-2.5 rounded-lg font-bold text-sm ${p.pop?'bg-brand text-white shadow-lg shadow-brand/25':'border border-white/10 text-slate-300'}`}>
                {p.price === 0 ? 'Start Free' : 'Start Trial'}
              </Link>
            </div>))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="px-6 py-14">
        <div className="max-w-2xl mx-auto text-center bg-bg-2 rounded-2xl p-12 border border-white/[.06] relative overflow-hidden">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,rgba(59,130,246,.08),transparent_50%)]" />
          <div className="relative">
            <h2 className="text-2xl font-extrabold mb-2">Start scanning markets with AI.</h2>
            <p className="text-sm text-slate-400 max-w-sm mx-auto mb-6">Free trial. $100K demo balance. No credit card.</p>
            <Link to="/signup" className="inline-block px-8 py-3 bg-brand text-white font-bold rounded-xl shadow-lg shadow-brand/25">Get Started Free →</Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="px-6 py-5 border-t border-white/[.04]">
        <div className="max-w-6xl mx-auto flex justify-between items-center flex-wrap gap-3">
          <div className="flex items-center gap-2"><div className="w-5 h-5 bg-brand rounded flex items-center justify-center"><Zap size={10} className="text-white" /></div><span className="text-xs font-bold">NEXUS<span className="text-brand">.ai</span></span></div>
          <span className="text-[9px] text-slate-700 max-w-md text-right">© 2026 Nexus AI. Educational platform only. Not financial advice. All trading uses demo money. Past performance ≠ future results.</span>
        </div>
      </footer>
    </div>
  );
}
