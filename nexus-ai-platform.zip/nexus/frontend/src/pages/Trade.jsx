// Trade page
import { useState } from 'react';
import useStore from '../hooks/useStore';
import { trade as tradeAPI } from '../utils/api';

export default function Trade() {
  const { prices, fetchPortfolio, portfolio } = useStore();
  const [sym, setSym] = useState('BTC');
  const [side, setSide] = useState('long');
  const [ot, setOT] = useState('market');
  const [amt, setAmt] = useState('');
  const [lp, setLP] = useState('');
  const [sl, setSL] = useState('');
  const [tp, setTP] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [err, setErr] = useState('');

  const a = prices[sym]; const usd = parseFloat(amt) || 0;
  const price = ot === 'limit' && lp ? parseFloat(lp) : (a?.price || 0);
  const qty = price > 0 ? usd / price : 0; const fee = usd * 0.001;
  const allSyms = Object.values(prices).filter(p => p?.symbol).sort((a, b) => a.symbol.localeCompare(b.symbol));

  const exec = async () => {
    setErr(''); setResult(null); if (usd <= 0) return setErr('Enter amount');
    setLoading(true);
    try {
      const { data } = await tradeAPI.order({ symbol: sym, side, amount: usd, orderType: ot, limitPrice: lp || undefined, stopLoss: sl || undefined, takeProfit: tp || undefined });
      setResult(data.message); setAmt(''); setSL(''); setTP(''); fetchPortfolio();
    } catch (e) { setErr(e.response?.data?.message || 'Failed'); }
    setLoading(false);
  };

  return (
    <div className="flex flex-col gap-4">
      <h1 className="text-lg font-extrabold tracking-tight">Trade <span className="text-xs text-amber-400 font-normal ml-2 bg-amber-500/10 px-2 py-0.5 rounded">DEMO MONEY</span></h1>
      <div className="grid grid-cols-[1fr_340px] gap-3">
        <div className="bg-bg-2 border border-white/[.06] rounded-xl p-5">
          <div className="flex items-center gap-3 mb-4">
            <select value={sym} onChange={e => setSym(e.target.value)} className="px-3 py-2 rounded-lg border border-white/10 bg-bg-3 text-xs font-bold font-mono text-white">{allSyms.map(s => <option key={s.symbol} value={s.symbol}>{s.symbol} — {s.name}</option>)}</select>
          </div>
          <div className="flex items-baseline gap-3 mb-4">
            <span className="text-2xl font-extrabold font-mono">${(a?.price || 0).toLocaleString(undefined, { maximumFractionDigits: (a?.price || 0) > 100 ? 2 : 4 })}</span>
            <span className={`text-sm font-bold font-mono ${(a?.change_pct || 0) >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>{(a?.change_pct || 0) >= 0 ? '▲' : '▼'} {Math.abs(a?.change_pct || 0).toFixed(2)}%</span>
            <span className="text-[9px] text-slate-500 capitalize border border-white/10 px-2 py-0.5 rounded">{a?.type}</span>
          </div>
          <div className="grid grid-cols-4 gap-2">
            {[{l:'Volume',v:a?.volume?`$${(a.volume/1e6).toFixed(1)}M`:'—'},{l:'Market Cap',v:a?.market_cap?`$${(a.market_cap/1e9).toFixed(1)}B`:'—'},{l:'24h High',v:a?.high_24h?`$${a.high_24h}`:'—'},{l:'24h Low',v:a?.low_24h?`$${a.low_24h}`:'—'}].map(s=>(
              <div key={s.l} className="p-2.5 bg-bg-3 rounded-lg"><div className="text-[8px] text-slate-500 tracking-wider uppercase">{s.l}</div><div className="text-xs font-bold font-mono mt-1">{s.v}</div></div>
            ))}
          </div>
        </div>

        <div className="bg-bg-2 border border-white/[.06] rounded-xl p-4 flex flex-col gap-3">
          <div className="text-sm font-bold">New Order</div>
          <div className="grid grid-cols-2 gap-0.5 bg-bg-3 rounded-lg p-0.5">
            <button onClick={()=>setSide('long')} className={`py-2 rounded-md text-xs font-bold ${side==='long'?'bg-emerald-500/10 text-emerald-400':'text-slate-500'}`}>Buy / Long</button>
            <button onClick={()=>setSide('short')} className={`py-2 rounded-md text-xs font-bold ${side==='short'?'bg-red-500/10 text-red-400':'text-slate-500'}`}>Sell / Short</button>
          </div>
          <div className="flex gap-0.5 bg-bg-3 rounded-lg p-0.5">{['market','limit','stop'].map(t=><button key={t} onClick={()=>setOT(t)} className={`flex-1 py-1.5 rounded-md text-xs font-semibold capitalize ${ot===t?'bg-bg-5 text-white':'text-slate-500'}`}>{t}</button>)}</div>
          <div><label className="text-[9px] text-slate-400 font-semibold block mb-1">AMOUNT (USD)</label><input type="number" value={amt} onChange={e=>setAmt(e.target.value)} placeholder="0.00" className="w-full px-3 py-2 rounded-lg border border-white/10 bg-bg-3 text-sm font-mono text-white" /></div>
          {ot==='limit'&&<div><label className="text-[9px] text-slate-400 font-semibold block mb-1">LIMIT PRICE</label><input type="number" value={lp} onChange={e=>setLP(e.target.value)} placeholder={(a?.price||0).toFixed(2)} className="w-full px-3 py-2 rounded-lg border border-white/10 bg-bg-3 text-sm font-mono text-white" /></div>}
          <div className="grid grid-cols-2 gap-2">
            <div><label className="text-[9px] text-slate-400 font-semibold block mb-1">STOP LOSS</label><input type="number" value={sl} onChange={e=>setSL(e.target.value)} placeholder="Optional" className="w-full px-2.5 py-2 rounded-lg border border-white/10 bg-bg-3 text-xs font-mono text-white" /></div>
            <div><label className="text-[9px] text-slate-400 font-semibold block mb-1">TAKE PROFIT</label><input type="number" value={tp} onChange={e=>setTP(e.target.value)} placeholder="Optional" className="w-full px-2.5 py-2 rounded-lg border border-white/10 bg-bg-3 text-xs font-mono text-white" /></div>
          </div>
          {usd>0&&<div className="p-2.5 bg-bg-3 rounded-lg text-[10px] flex flex-col gap-1">{[['Qty',`${qty.toFixed(qty>1?4:6)} ${sym}`],['Price',`$${price.toLocaleString()}`],['Fee (0.1%)',`$${fee.toFixed(2)}`],['Total',`$${(usd+fee).toFixed(2)}`]].map(([k,v])=>(<div key={k} className="flex justify-between"><span className="text-slate-500">{k}</span><span className="text-white font-mono">{v}</span></div>))}</div>}
          {err&&<div className="p-2 bg-red-500/10 border border-red-500/15 rounded-lg text-[10px] text-red-400">{err}</div>}
          {result&&<div className="p-2 bg-emerald-500/[.06] border border-emerald-500/10 rounded-lg text-[10px] text-emerald-400">✓ {result}</div>}
          <button onClick={exec} disabled={loading||usd<=0} className={`w-full py-2.5 font-bold rounded-lg text-sm disabled:opacity-40 ${side==='long'?'bg-emerald-500 text-white shadow-lg shadow-emerald-500/20':'bg-red-500 text-white shadow-lg shadow-red-500/20'}`}>{loading?'Executing...':`${side==='long'?'Buy':'Sell'} ${sym} (Demo)`}</button>
          <div className="text-[9px] text-slate-500">Balance: <span className="text-white font-mono">${(portfolio?.balance||100000).toLocaleString()}</span></div>
        </div>
      </div>
    </div>
  );
}
