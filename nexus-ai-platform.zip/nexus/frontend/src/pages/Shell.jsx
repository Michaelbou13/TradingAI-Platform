import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { useEffect } from 'react';
import useStore from '../hooks/useStore';
import useWS from '../hooks/useWS';
import { Zap, LayoutDashboard, BarChart3, Brain, Crosshair, ArrowLeftRight, Briefcase, Clock, Settings, LogOut, AlertTriangle } from 'lucide-react';

const nav = [
  { to: '/app', icon: LayoutDashboard, label: 'Dashboard', end: true },
  { to: '/app/markets', icon: BarChart3, label: 'Markets' },
  { to: '/app/scanner', icon: Brain, label: 'AI Scanner', live: true },
  { to: '/app/trade', icon: ArrowLeftRight, label: 'Trade' },
  { to: '/app/portfolio', icon: Briefcase, label: 'Portfolio' },
  { to: '/app/history', icon: Clock, label: 'History' },
  { to: '/app/settings', icon: Settings, label: 'Settings' },
];

export default function Shell() {
  const { user, logout, fetchPrices, fetchPortfolio, fetchSignals } = useStore();
  const navigate = useNavigate();
  useWS();

  useEffect(() => { fetchPrices(); fetchPortfolio(); fetchSignals(); const iv = setInterval(() => { fetchPrices(); fetchPortfolio(); }, 30000); return () => clearInterval(iv); }, []);

  return (
    <div className="flex min-h-screen bg-bg">
      <aside className="w-[196px] bg-bg-2 border-r border-white/[.04] flex flex-col fixed inset-y-0 left-0 z-50">
        <div className="p-3.5 border-b border-white/[.04] flex items-center gap-2">
          <div className="w-7 h-7 bg-brand rounded-lg flex items-center justify-center"><Zap size={14} className="text-white" /></div>
          <span className="text-sm font-extrabold">NEXUS<span className="text-brand">.ai</span></span>
        </div>
        <nav className="flex-1 p-1.5 flex flex-col gap-0.5 mt-0.5">
          {nav.map(n => (
            <NavLink key={n.to} to={n.to} end={n.end} className={({isActive}) => `flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium transition-all ${isActive?'bg-brand/10 text-brand font-semibold':'text-slate-400 hover:text-slate-200 hover:bg-white/[.02]'}`}>
              <n.icon size={14} />{n.label}
              {n.live && <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 ml-auto" style={{animation:'pulse 2s infinite'}} />}
            </NavLink>
          ))}
        </nav>
        {/* Disclaimer */}
        <div className="px-3 pb-2">
          <div className="flex items-start gap-1.5 p-2 bg-amber-500/[.04] border border-amber-500/[.08] rounded-lg">
            <AlertTriangle size={10} className="text-amber-400 mt-0.5 flex-shrink-0" />
            <span className="text-[8px] text-amber-400/70 leading-relaxed">Demo money only. Not financial advice.</span>
          </div>
        </div>
        <div className="p-3 border-t border-white/[.04]">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-6 h-6 rounded-md bg-brand/10 flex items-center justify-center text-[10px] font-bold text-brand">{(user?.name||'T')[0].toUpperCase()}</div>
            <div><div className="text-[10px] font-semibold text-slate-200">{user?.name}</div><div className="text-[8px] text-slate-500 capitalize">{user?.plan} • ${(user?.balance||0).toLocaleString(undefined,{maximumFractionDigits:0})}</div></div>
          </div>
          <button onClick={() => { logout(); navigate('/'); }} className="flex items-center gap-1.5 text-[10px] text-slate-500 hover:text-slate-300"><LogOut size={10} />Sign Out</button>
        </div>
      </aside>
      <main className="ml-[196px] flex-1 p-5 min-h-screen"><div className="fade-in"><Outlet /></div></main>
    </div>
  );
}
