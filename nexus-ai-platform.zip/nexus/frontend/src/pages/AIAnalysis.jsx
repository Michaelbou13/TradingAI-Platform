import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ai, market } from '../utils/api';
import useStore from '../hooks/useStore';

export default function AIAnalysis() {
  const { symbol } = useParams();
  const { prices } = useStore();
  const [analysis, setAnalysis] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const live = prices[symbol];

  useEffect(() => {
    setLoading(true); setError('');
    ai.analyze(symbol).then(r => { setAnalysis(r.data.analysis); setLoading(false); })
      .catch(e => { setError(e.response?.data?.message || 'Analysis failed'); setLoading(false); });
  }, [symbol]);

  if (loading) return <div className="flex items-center justify-center py-32"><div className="text-center"><div className="text-2xl mb-3">⚡</div><div className="text-sm text-brand font-semibold">Analyzing {symbol}...</div><div className="text-[10px] text-slate-500 mt-1">Running 12 technical indicators</div></div></div>;
  if (error) return <div className="text-center py-32 text-sm text-red-400">{error}</div>;
  if (!analysis) return null;

  const ind = analysis.indicators || {};
  const sigs = analysis.signals || [];

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center gap-3">
        <Link to="/app/scanner" className="text-xs text-slate-500 hover:text-white">← Scanner</Link>
        <Link to="/app/markets" className="text-xs text-slate-500 hover:text-white">Markets</Link>
      </div>

      {/* Header */}
      <div className="bg-bg-2 border border-white/[.06] rounded-xl p-5">
        <div className="flex justify-between items-start">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <span className="text-2xl font-extrabold">{analysis.symbol}</span>
              <span className="text-sm text-slate-400">{analysis.name}</span>
              <span className={`text-[9px] font-semibold px-2 py-0.5 rounded capitalize ${analysis.asset_type === 'crypto' ? 'bg-purple-500/10 text-purple-400' : analysis.asset_type === 'forex' ? 'bg-cyan-500/10 text-cyan-400' : 'bg-blue-500/10 text-blue-400'}`}>{analysis.asset_type}</span>
            </div>
            <div className="flex items-baseline gap-3">
              <span className="text-3xl font-extrabold font-mono">${(live?.price || analysis.price).toLocaleString(undefined, { maximumFractionDigits: analysis.price > 100 ? 2 : 4 })}</span>
              <span className={`text-sm font-bold font-mono ${(live?.change_pct || 0) >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>{(live?.change_pct || 0) >= 0 ? '▲' : '▼'} {Math.abs(live?.change_pct || 0).toFixed(2)}%</span>
            </div>
          </div>
          <div className="text-right">
            <span className={`text-2xl font-extrabold ${analysis.action === 'BUY' ? 'text-emerald-400' : analysis.action === 'SELL' ? 'text-red-400' : 'text-slate-400'}`}>{analysis.action}</span>
            <div className="flex items-center gap-2 mt-1">
              <div className="w-20 h-2 rounded bg-bg-4"><div className={`h-full rounded ${analysis.confidence >= 80 ? 'bg-blue-500' : 'bg-cyan-500'}`} style={{width:`${analysis.confidence}%`}} /></div>
              <span className="text-sm font-bold text-blue-400 font-mono">{analysis.confidence}%</span>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-[1fr_340px] gap-3">
        {/* AI Summary + Signals */}
        <div className="flex flex-col gap-3">
          <div className="bg-bg-2 border border-white/[.06] rounded-xl p-5">
            <div className="text-sm font-bold mb-3">🤖 AI Summary</div>
            <p className="text-sm text-slate-300 leading-relaxed">{analysis.summary}</p>
          </div>

          <div className="bg-bg-2 border border-white/[.06] rounded-xl p-5">
            <div className="text-sm font-bold mb-3">📊 Signal Breakdown</div>
            <div className="flex flex-col gap-2">
              {sigs.map((s, i) => (
                <div key={i} className="flex items-start gap-2 p-2.5 bg-bg-3 rounded-lg">
                  <span className={`mt-0.5 text-[10px] ${s.includes('bullish') || s.includes('buy') || s.includes('BUY') || s.includes('oversold') || s.includes('above') || s.includes('positive') || s.includes('upside') ? 'text-emerald-400' : s.includes('bearish') || s.includes('overbought') || s.includes('below') || s.includes('negative') || s.includes('risk') || s.includes('weakness') ? 'text-red-400' : 'text-slate-400'}`}>●</span>
                  <span className="text-xs text-slate-300 leading-relaxed">{s}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Trade Parameters */}
          <div className="bg-bg-2 border border-white/[.06] rounded-xl p-5">
            <div className="text-sm font-bold mb-3">🎯 Trade Parameters</div>
            <div className="grid grid-cols-4 gap-3">
              {[{l:'Target',v:`${analysis.target_pct>0?'+':''}${analysis.target_pct}%`,c:'text-emerald-400'},{l:'Stop Loss',v:`${analysis.stop_pct}%`,c:'text-red-400'},{l:'Risk:Reward',v:`${analysis.risk_reward}x`,c:'text-blue-400'},{l:'Timeframe',v:analysis.timeframe,c:'text-white'}].map(m=>(
                <div key={m.l} className="p-3 bg-bg-3 rounded-lg"><div className="text-[8px] text-slate-500 tracking-wider uppercase">{m.l}</div><div className={`text-lg font-bold font-mono mt-1 ${m.c}`}>{m.v}</div></div>
              ))}
            </div>
            <Link to={`/app/trade`} className="mt-4 block text-center py-2.5 bg-brand text-white text-sm font-bold rounded-lg shadow-lg shadow-brand/25">Trade {symbol} (Demo) →</Link>
            <p className="text-[9px] text-slate-600 text-center mt-2">Demo money only. Not financial advice.</p>
          </div>
        </div>

        {/* Indicators Panel */}
        <div className="flex flex-col gap-3">
          <div className="bg-bg-2 border border-white/[.06] rounded-xl p-4">
            <div className="text-sm font-bold mb-3">📈 Technical Indicators</div>
            <div className="flex flex-col gap-2">
              {[
                {l:'RSI (14)',v:ind.rsi?.toFixed(1),good:ind.rsi<40,bad:ind.rsi>70},
                {l:'MACD',v:ind.macd?.toFixed(4),good:ind.macd>0,bad:ind.macd<0},
                {l:'Stochastic',v:ind.stochastic?.toFixed(1),good:ind.stochastic<30,bad:ind.stochastic>80},
                {l:'EMA 21',v:`$${ind.ema21?.toFixed(2)}`,good:analysis.price>ind.ema21},
                {l:'EMA 55',v:`$${ind.ema55?.toFixed(2)}`,good:analysis.price>ind.ema55},
                {l:'SMA 20',v:`$${ind.sma20?.toFixed(2)}`,good:analysis.price>ind.sma20},
                {l:'SMA 50',v:`$${ind.sma50?.toFixed(2)}`,good:analysis.price>ind.sma50},
                {l:'BB Upper',v:`$${ind.bb_upper?.toFixed(2)}`},
                {l:'BB Lower',v:`$${ind.bb_lower?.toFixed(2)}`},
                {l:'BB Width',v:(ind.bb_width*100)?.toFixed(2)+'%'},
                {l:'ATR',v:ind.atr?.toFixed(4)},
                {l:'Price vs SMA20',v:`${ind.price_vs_sma20?.toFixed(2)}%`,good:ind.price_vs_sma20>0,bad:ind.price_vs_sma20<0},
              ].map(r=>(
                <div key={r.l} className="flex justify-between items-center py-1.5 border-b border-white/[.03]">
                  <span className="text-[10px] text-slate-400">{r.l}</span>
                  <span className={`text-[11px] font-bold font-mono ${r.good?'text-emerald-400':r.bad?'text-red-400':'text-white'}`}>{r.v||'—'}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-bg-2 border border-white/[.06] rounded-xl p-4">
            <div className="text-sm font-bold mb-3">🔍 Market Context</div>
            <div className="flex flex-col gap-2">
              {[{l:'Trend',v:ind.trend,c:ind.trend==='bullish'?'text-emerald-400':'text-red-400'},{l:'Momentum',v:ind.momentum,c:ind.momentum==='positive'?'text-emerald-400':'text-red-400'},{l:'Volatility',v:ind.volatility,c:'text-white'},{l:'AI Score',v:analysis.score,c:analysis.score>0?'text-emerald-400':'text-red-400'}].map(r=>(
                <div key={r.l} className="flex justify-between items-center py-1.5 border-b border-white/[.03]">
                  <span className="text-[10px] text-slate-400">{r.l}</span>
                  <span className={`text-[11px] font-bold font-mono capitalize ${r.c}`}>{r.v}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
