import { useState, useEffect } from 'react';
import useStore from '../hooks/useStore';
import { settings as setAPI, auth as authAPI } from '../utils/api';

function Tog({ on, onClick }) { return <button onClick={onClick} className={`w-10 h-5 rounded-full relative transition-colors ${on?'bg-blue-500':'bg-bg-4'}`}><div className={`w-4 h-4 rounded-full bg-white absolute top-0.5 transition-all ${on?'left-[22px]':'left-0.5'}`}/></button>; }

export default function Settings() {
  const { user } = useStore();
  const [n, setN] = useState({});
  const [risk, setRisk] = useState('medium');
  const [name, setName] = useState(user?.name||'');
  const [email, setEmail] = useState(user?.email||'');
  const [msg, setMsg] = useState('');

  useEffect(() => { setAPI.get().then(r => { if(r.data.settings) setN(r.data.settings); if(r.data.user?.risk_level) setRisk(r.data.user.risk_level); }).catch(()=>{}); }, []);
  const flash = m => { setMsg(m); setTimeout(()=>setMsg(''),2500); };
  const saveProfile = async () => { try { await authAPI.updateProfile({name,email}); flash('Profile saved'); } catch(e) { flash(e.response?.data?.message||'Failed'); } };
  const saveRisk = async r => { setRisk(r); try { await setAPI.updateRisk({risk_level:r}); flash(`Risk: ${r}`); } catch{} };
  const toggleN = k => { const u = {...n,[k]:!n[k]}; setN(u); setAPI.update(u).catch(()=>{}); };

  return (
    <div className="flex flex-col gap-3 max-w-xl">
      <h1 className="text-lg font-extrabold tracking-tight">Settings</h1>
      {msg&&<div className="p-2 bg-emerald-500/[.06] border border-emerald-500/10 rounded-lg text-[10px] text-emerald-400 font-semibold">✓ {msg}</div>}

      <div className="bg-bg-2 border border-white/[.06] rounded-xl p-4">
        <div className="text-sm font-bold mb-3">Profile</div>
        <div className="grid grid-cols-2 gap-2.5">
          <div><label className="text-[9px] text-slate-400 font-semibold block mb-1">NAME</label><input value={name} onChange={e=>setName(e.target.value)} className="w-full px-2.5 py-2 rounded-lg border border-white/10 bg-bg-3 text-xs text-white" /></div>
          <div><label className="text-[9px] text-slate-400 font-semibold block mb-1">EMAIL</label><input value={email} onChange={e=>setEmail(e.target.value)} className="w-full px-2.5 py-2 rounded-lg border border-white/10 bg-bg-3 text-xs font-mono text-white" /></div>
        </div>
        <button onClick={saveProfile} className="mt-3 px-4 py-2 bg-brand text-white text-xs font-semibold rounded-lg">Save</button>
      </div>

      <div className="bg-bg-2 border border-white/[.06] rounded-xl p-4">
        <div className="text-sm font-bold mb-3">Notifications</div>
        {[['notify_email','Email'],['notify_push','Push'],['notify_sms','SMS'],['notify_discord','Discord']].map(([k,l])=>(
          <div key={k} className="flex justify-between items-center py-2.5 border-b border-white/[.04]"><span className="text-xs text-white">{l} Alerts</span><Tog on={!!n[k]} onClick={()=>toggleN(k)} /></div>
        ))}
      </div>

      <div className="bg-bg-2 border border-white/[.06] rounded-xl p-4">
        <div className="text-sm font-bold mb-1">Risk Tolerance</div>
        <div className="text-[10px] text-slate-400 mb-3">AI adjusts signal aggressiveness based on this.</div>
        <div className="grid grid-cols-3 gap-2">
          {['conservative','medium','aggressive'].map(r=>(
            <button key={r} onClick={()=>saveRisk(r)} className={`p-3 rounded-lg text-left border ${risk===r?'border-blue-500 bg-blue-500/[.06]':'border-white/[.06]'}`}>
              <div className={`text-xs font-semibold capitalize ${risk===r?'text-blue-400':'text-slate-300'}`}>{r}</div>
            </button>
          ))}
        </div>
      </div>

      <div className="bg-bg-2 border border-white/[.06] rounded-xl p-4">
        <div className="text-sm font-bold mb-3">Subscription</div>
        <div className="flex justify-between items-center p-3 bg-blue-500/[.06] border border-blue-500/10 rounded-lg">
          <div><div className="text-sm font-bold text-blue-400 capitalize">{user?.plan||'Free'} Plan</div><div className="text-[10px] text-slate-400 mt-0.5">{user?.plan==='pro'?'Unlimited scans • All markets • Demo trading':'3 scans/day • Basic features'}</div></div>
          <span className="text-[9px] font-bold px-2 py-0.5 bg-emerald-500/10 text-emerald-400 rounded">ACTIVE</span>
        </div>
      </div>

      <div className="bg-bg-2 border border-white/[.06] rounded-xl p-4">
        <div className="text-sm font-bold mb-2">Account</div>
        <div className="text-[10px] text-slate-400 space-y-1">
          <div>ID: <span className="font-mono text-slate-300">{user?.id?.slice(0,8)}</span></div>
          <div>Balance: <span className="font-mono text-white">${(user?.balance||0).toLocaleString()}</span> <span className="text-amber-400">(demo)</span></div>
          <div>Joined: {user?.created_at?new Date(user.created_at).toLocaleDateString():'—'}</div>
        </div>
      </div>
    </div>
  );
}
