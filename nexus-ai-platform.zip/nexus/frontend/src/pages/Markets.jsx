import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import useStore from '../hooks/useStore';

export default function Markets() {
  const { prices, fetchPrices } = useStore();
  const [filter, setFilter] = useState('all');
  const [search, setSearch] = useState('');
  const [sort, setSort] = useState('symbol');

  useEffect(() => { fetchPrices(); }, []);

  let list = Object.values(prices).filter(a => a?.symbol);
  if (filter !== 'all') list = list.filter(a => a.type === filter);
  if (search) { const q = search.toUpperCase(); list = list.filter(a => a.symbol.includes(q) || a.name?.toUpperCase().includes(q)); }
  if (sort === 'change') list.sort((a, b) => Math.abs(b.change_pct || 0) - Math.abs(a.change_pct || 0));
  else if (sort === 'price') list.sort((a, b) => (b.price || 0) - (a.price || 0));
  else list.sort((a, b) => a.symbol.localeCompare(b.symbol));

  return (
    <div className="flex flex-col gap-4">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-lg font-extrabold tracking-tight">Markets</h1>
          <p className="text-[10px] text-slate-500">{list.length} assets across crypto, stocks & forex • Click any asset for AI analysis</p>
        </div>
        <div className="flex gap-2">
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search..." className="px-3 py-1.5 rounded-lg border border-white/10 bg-bg-3 text-xs text-white w-40" />
          <select value={sort} onChange={e => setSort(e.target.value)} className="px-2 py-1.5 rounded-lg border border-white/10 bg-bg-3 text-xs text-white">
            <option value="symbol">A-Z</option><option value="change">Top Movers</option><option value="price">Price</option>
          </select>
        </div>
      </div>

      <div className="flex gap-1 bg-bg-3 rounded-lg p-0.5 w-fit">
        {[['all','All'],['crypto','Crypto'],['stock','Stocks'],['forex','Forex']].map(([v,l]) => (
          <button key={v} onClick={() => setFilter(v)} className={`px-4 py-1.5 rounded-md text-xs font-semibold ${filter === v ? 'bg-bg-5 text-white' : 'text-slate-500'}`}>{l} <span className="text-slate-600 ml-1">{v === 'all' ? Object.values(prices).length : Object.values(prices).filter(a => a.type === v).length}</span></button>
        ))}
      </div>

      <div className="bg-bg-2 border border-white/[.06] rounded-xl overflow-hidden">
        <div className="grid grid-cols-7 gap-3 px-4 py-2 text-[8px] font-semibold text-slate-500 tracking-widest uppercase border-b border-white/[.04]">
          <span>Symbol</span><span>Name</span><span>Type</span><span>Price</span><span>24h Change</span><span>Volume</span><span>AI</span>
        </div>
        {list.map(a => (
          <Link key={a.symbol} to={`/app/analyze/${a.symbol}`} className="grid grid-cols-7 gap-3 px-4 py-2.5 border-b border-white/[.02] items-center hover:bg-white/[.01] transition-colors">
            <span className="text-[11px] font-bold font-mono">{a.symbol}</span>
            <span className="text-[10px] text-slate-400 truncate">{a.name}</span>
            <span className={`text-[9px] font-semibold px-1.5 py-0.5 rounded w-fit capitalize ${a.type === 'crypto' ? 'bg-purple-500/10 text-purple-400' : a.type === 'forex' ? 'bg-cyan-500/10 text-cyan-400' : 'bg-blue-500/10 text-blue-400'}`}>{a.type}</span>
            <span className="text-[11px] font-bold font-mono">${(a.price || 0).toLocaleString(undefined, { maximumFractionDigits: a.price > 100 ? 2 : a.price > 1 ? 4 : 6 })}</span>
            <span className={`text-[10px] font-bold font-mono ${(a.change_pct || 0) >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>{(a.change_pct || 0) >= 0 ? '+' : ''}{(a.change_pct || 0).toFixed(2)}%</span>
            <span className="text-[10px] text-slate-400 font-mono">{a.volume ? `$${(a.volume / 1e6).toFixed(1)}M` : '—'}</span>
            <span className="text-[10px] text-brand font-semibold">Analyze →</span>
          </Link>
        ))}
        {list.length === 0 && <div className="p-10 text-center text-xs text-slate-500">No assets found</div>}
      </div>
    </div>
  );
}
