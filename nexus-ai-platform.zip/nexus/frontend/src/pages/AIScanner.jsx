import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ai } from '../utils/api';
import useStore from '../hooks/useStore';

export default function AIScanner() {
  const { signals, fetchSignals } = useStore();
  const [scanResults, setScanResults] = useState(null);
  const [scanning, setScanning] = useState(false);
  const [filter, setFilter] = useState({});
  const [stats, setStats] = useState(null);

  useEffect(() => { fetchSignals(); ai.stats().then(r => setStats(r.data)).catch(() => {}); }, []);

  const runScan = async () => {
    setScanning(true);
    try {
      const { data } = await ai.scan(filter);
      setScanResults(data.results);
    } catch (e) { console.error(e); }
    setScanning(false);
  };

  const list = scanResults || signals || [];

  return (
    <div className="flex flex-col gap-4">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-lg font-extrabold tracking-tight">AI Market Scanner</h1>
          <p className="text-[10px] text-slate-500">Scan all markets for high-probability trading opportunities</p>
        </div>
        <div className="flex items-center gap-2"><span className="w-1.5 h-1.5 rounded-full bg-emerald-400" style={{animation:'pulse 2s infinite'}} /><span className="text-[10px] text-emerald-400 font-semibold">LIVE</span></div>
      </div>

      {/* Scan Controls */}
      <div className="bg-bg-2 border border-white/[.06] rounded-xl p-4">
        <div className="flex items-center gap-3 flex-wrap">
          <select value={filter.type||''} onChange={e=>setFilter({...filter,type:e.target.value||undefined})} className="px-3 py-2 rounded-lg border border-white/10 bg-bg-3 text-xs text-white"><option value="">All Markets</option><option value="crypto">Crypto</option><option value="stock">Stocks</option><option value="forex">Forex</option></select>
          <select value={filter.action||''} onChange={e=>setFilter({...filter,action:e.target.value||undefined})} className="px-3 py-2 rounded-lg border border-white/10 bg-bg-3 text-xs text-white"><option value="">All Signals</option><option value="BUY">Buy Only</option><option value="SELL">Sell Only</option></select>
          <select value={filter.minConf||60} onChange={e=>setFilter({...filter,minConf:e.target.value})} className="px-3 py-2 rounded-lg border border-white/10 bg-bg-3 text-xs text-white"><option value="60">60%+ Confidence</option><option value="70">70%+</option><option value="80">80%+</option><option value="90">90%+</option></select>
          <button onClick={runScan} disabled={scanning} className="px-5 py-2 bg-brand text-white text-xs font-bold rounded-lg shadow-lg shadow-brand/25 disabled:opacity-50">{scanning ? 'Scanning...' : '⚡ Run AI Scan'}</button>
          {scanResults && <button onClick={() => setScanResults(null)} className="text-xs text-slate-400 hover:text-white">Clear</button>}
        </div>
        {stats && (
          <div className="flex gap-6 mt-3 pt-3 border-t border-white/[.04]">
            {[{l:'Active Signals',v:stats.active},{l:'Buy Signals',v:stats.buys,c:'text-emerald-400'},{l:'Sell Signals',v:stats.sells,c:'text-red-400'},{l:'Avg Confidence',v:`${stats.avgConfidence}%`,c:'text-blue-400'}].map(s=>(
              <div key={s.l}><div className="text-[8px] text-slate-500 tracking-wider uppercase">{s.l}</div><div className={`text-sm font-bold font-mono ${s.c||'text-white'}`}>{s.v}</div></div>
            ))}
          </div>
        )}
      </div>

      {/* Results */}
      <div className="grid grid-cols-2 gap-2.5">
        {list.map(s => {
          const indicators = typeof s.indicators === 'string' ? JSON.parse(s.indicators) : (s.indicators || {});
          const analysis = typeof s.analysis === 'string' ? JSON.parse(s.analysis) : (s.analysis || []);
          return (
            <Link key={s.id} to={`/app/analyze/${s.symbol}`} className="bg-bg-2 border border-white/[.06] rounded-xl p-4 hover:border-white/[.1] transition-colors">
              <div className="flex justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${s.action === 'BUY' ? 'bg-emerald-500/10 text-emerald-400' : s.action === 'SELL' ? 'bg-red-500/10 text-red-400' : 'bg-slate-500/10 text-slate-400'}`}>{s.action}</span>
                  <span className="text-sm font-extrabold font-mono">{s.symbol}</span>
                  <span className={`text-[8px] font-semibold px-1.5 py-0.5 rounded capitalize ${s.asset_type === 'crypto' ? 'bg-purple-500/10 text-purple-400' : s.asset_type === 'forex' ? 'bg-cyan-500/10 text-cyan-400' : 'bg-blue-500/10 text-blue-400'}`}>{s.asset_type}</span>
                </div>
                <span className="text-[10px] text-slate-500 font-mono">{s.timeframe}</span>
              </div>

              <p className="text-[11px] text-slate-400 leading-relaxed mb-3 line-clamp-2">{s.summary}</p>

              <div className="flex gap-4 mb-3">
                {[{l:'Target',v:`${(s.target_pct||0)>0?'+':''}${(s.target_pct||0).toFixed(1)}%`,c:'text-emerald-400'},{l:'Stop',v:`${(s.stop_pct||0).toFixed(1)}%`,c:'text-red-400'},{l:'R:R',v:`${s.risk_reward||0}x`,c:'text-blue-400'},{l:'Price',v:`$${(s.price_at||s.price||0).toLocaleString(undefined,{maximumFractionDigits:2})}`,c:'text-white'}].map(m=>(
                  <div key={m.l}><div className="text-[8px] text-slate-500 tracking-wider uppercase">{m.l}</div><div className={`text-xs font-bold font-mono mt-0.5 ${m.c}`}>{m.v}</div></div>
                ))}
              </div>

              {/* Indicator pills */}
              <div className="flex gap-1.5 flex-wrap mb-3">
                {indicators.rsi && <span className={`text-[8px] font-mono px-1.5 py-0.5 rounded ${indicators.rsi < 30 ? 'bg-emerald-500/10 text-emerald-400' : indicators.rsi > 70 ? 'bg-red-500/10 text-red-400' : 'bg-slate-500/10 text-slate-400'}`}>RSI {indicators.rsi.toFixed(0)}</span>}
                {indicators.trend && <span className={`text-[8px] font-mono px-1.5 py-0.5 rounded ${indicators.trend === 'bullish' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-red-500/10 text-red-400'}`}>{indicators.trend}</span>}
                {indicators.volatility && <span className="text-[8px] font-mono px-1.5 py-0.5 rounded bg-slate-500/10 text-slate-400">Vol: {indicators.volatility}</span>}
              </div>

              {/* Confidence bar */}
              <div className="flex items-center gap-2">
                <div className="flex-1 h-1 rounded bg-bg-4"><div className={`h-full rounded transition-all ${s.confidence >= 80 ? 'bg-blue-500' : s.confidence >= 60 ? 'bg-cyan-500' : 'bg-slate-500'}`} style={{width:`${s.confidence}%`}} /></div>
                <span className={`text-[10px] font-bold font-mono ${s.confidence >= 80 ? 'text-blue-400' : 'text-cyan-400'}`}>{s.confidence}%</span>
              </div>
            </Link>
          );
        })}
      </div>
      {list.length === 0 && !scanning && <div className="text-center py-16 text-sm text-slate-500">No signals yet. Click "Run AI Scan" to analyze markets.</div>}
      {scanning && <div className="text-center py-16 text-sm text-brand">⚡ Scanning markets with AI...</div>}
    </div>
  );
}
