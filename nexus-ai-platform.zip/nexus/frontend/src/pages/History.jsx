import { useState, useEffect } from 'react';
import { portfolio as pfAPI } from '../utils/api';

export default function History() {
  const [trades, setTrades] = useState([]);
  const [stats, setStats] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([pfAPI.history({ limit: 50 }), pfAPI.performance()])
      .then(([h, p]) => { setTrades(h.data.trades || []); setStats(p.data.stats || {}); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  return (
    <div className="flex flex-col gap-4">
      <h1 className="text-lg font-extrabold tracking-tight">Trade History</h1>
      <div className="grid grid-cols-4 gap-2">
        {[{l:'Total Trades',v:stats.totalTrades||0},{l:'Win Rate',v:`${stats.winRate||0}%`,c:'text-emerald-400'},{l:'Total P&L',v:`$${parseFloat(stats.totalPnl||0).toLocaleString()}`,c:parseFloat(stats.totalPnl||0)>=0?'text-emerald-400':'text-red-400'},{l:'Profit Factor',v:stats.profitFactor||'N/A',c:'text-blue-400'}].map(s=>(
          <div key={s.l} className="bg-bg-2 border border-white/[.06] rounded-xl p-3.5"><div className="text-[8px] text-slate-500 tracking-widest uppercase font-semibold mb-1">{s.l}</div><div className={`text-lg font-bold font-mono ${s.c||'text-white'}`}>{s.v}</div></div>
        ))}
      </div>
      <div className="grid grid-cols-4 gap-2">
        {[{l:'Best Trade',v:`$${stats.best||0}`,c:'text-emerald-400'},{l:'Worst Trade',v:`$${stats.worst||0}`,c:'text-red-400'},{l:'Avg Win',v:`$${stats.avgWin||0}`,c:'text-emerald-400'},{l:'Avg Loss',v:`$${stats.avgLoss||0}`,c:'text-red-400'}].map(s=>(
          <div key={s.l} className="bg-bg-2 border border-white/[.06] rounded-xl p-3.5"><div className="text-[8px] text-slate-500 tracking-widest uppercase font-semibold mb-1">{s.l}</div><div className={`text-sm font-bold font-mono ${s.c}`}>{s.v}</div></div>
        ))}
      </div>
      <div className="bg-bg-2 border border-white/[.06] rounded-xl overflow-hidden">
        <div className="px-4 py-2.5 border-b border-white/[.04] text-sm font-bold">Closed Trades</div>
        <div className="grid grid-cols-7 gap-2 px-4 py-1.5 text-[8px] font-semibold text-slate-500 tracking-widest uppercase border-b border-white/[.04]"><span>Asset</span><span>Type</span><span>Side</span><span>Entry</span><span>Exit</span><span>P&L</span><span>Date</span></div>
        {loading?<div className="p-10 text-center text-xs text-slate-500">Loading...</div>:trades.length===0?<div className="p-10 text-center text-xs text-slate-500">No closed trades yet</div>:trades.map(t=>(
          <div key={t.id} className="grid grid-cols-7 gap-2 px-4 py-2.5 border-b border-white/[.02] items-center">
            <span className="text-[11px] font-bold font-mono">{t.symbol}</span>
            <span className="text-[9px] text-slate-400 capitalize">{t.asset_type}</span>
            <span className={`text-[8px] font-bold px-1.5 py-0.5 rounded w-fit ${t.side==='long'?'bg-emerald-500/10 text-emerald-400':'bg-red-500/10 text-red-400'}`}>{t.side?.toUpperCase()}</span>
            <span className="text-[10px] text-slate-400 font-mono">${t.entry_price}</span>
            <span className="text-[10px] text-white font-mono">${t.close_price||'—'}</span>
            <div><span className={`text-[10px] font-bold font-mono ${(t.pnl||0)>=0?'text-emerald-400':'text-red-400'}`}>{(t.pnl||0)>=0?'+':''}${(t.pnl||0).toFixed(2)}</span><span className="text-[8px] text-slate-500 ml-1">({(t.pnl_pct||0).toFixed(1)}%)</span></div>
            <span className="text-[9px] text-slate-500">{t.closed_at?new Date(t.closed_at).toLocaleDateString():'—'}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
