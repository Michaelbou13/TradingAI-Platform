import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import useStore from '../hooks/useStore';

export default function Dashboard() {
  const { portfolio, signals, prices, fetchPortfolio, fetchSignals } = useStore();
  useEffect(() => { fetchPortfolio(); fetchSignals(); }, []);

  const p = portfolio || {};
  const topMovers = Object.values(prices).filter(a => a?.change_pct !== undefined).sort((a, b) => Math.abs(b.change_pct) - Math.abs(a.change_pct)).slice(0, 8);
  const topSignals = (signals || []).slice(0, 6);

  return (
    <div className="flex flex-col gap-4">
      <div className="flex justify-between items-center">
        <h1 className="text-lg font-extrabold tracking-tight">Dashboard</h1>
        <Link to="/app/scanner" className="text-xs font-semibold text-brand bg-brand/10 px-3 py-1.5 rounded-lg hover:bg-brand/15">Run AI Scanner →</Link>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-5 gap-2">
        {[
          { l: 'Portfolio', v: `$${(p.totalValue || 100000).toLocaleString(undefined, { maximumFractionDigits: 0 })}`, c: 'text-white' },
          { l: 'P&L', v: `${(p.totalPnl || 0) >= 0 ? '+' : ''}$${(p.totalPnl || 0).toLocaleString(undefined, { maximumFractionDigits: 0 })}`, c: (p.totalPnl || 0) >= 0 ? 'text-emerald-400' : 'text-red-400' },
          { l: 'Win Rate', v: `${p.winRate || 0}%`, c: 'text-blue-400' },
          { l: 'Positions', v: `${(p.positions || []).length}`, c: 'text-white' },
          { l: 'AI Signals', v: `${(signals || []).length}`, c: 'text-cyan-400' },
        ].map(s => (
          <div key={s.l} className="bg-bg-2 border border-white/[.06] rounded-xl p-3.5">
            <div className="text-[9px] text-slate-500 tracking-widest uppercase font-semibold mb-1">{s.l}</div>
            <div className={`text-lg font-bold font-mono ${s.c}`}>{s.v}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-[1fr_340px] gap-3">
        {/* Top Movers */}
        <div className="bg-bg-2 border border-white/[.06] rounded-xl p-4">
          <div className="flex justify-between items-center mb-3">
            <span className="text-sm font-bold">Top Movers</span>
            <Link to="/app/markets" className="text-[10px] text-brand">View All →</Link>
          </div>
          <div className="grid grid-cols-4 gap-2">
            {topMovers.map(m => (
              <Link key={m.symbol} to={`/app/analyze/${m.symbol}`} className="p-2.5 bg-bg-3 rounded-lg hover:bg-bg-4 transition-colors">
                <div className="flex justify-between items-center mb-1">
                  <span className="text-[11px] font-bold">{m.symbol}</span>
                  <span className={`text-[9px] font-bold font-mono ${(m.change_pct || 0) >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>{(m.change_pct || 0) >= 0 ? '+' : ''}{(m.change_pct || 0).toFixed(1)}%</span>
                </div>
                <div className="text-xs font-bold font-mono">${(m.price || 0).toLocaleString(undefined, { maximumFractionDigits: m.price > 100 ? 0 : m.price > 1 ? 2 : 4 })}</div>
                <div className="text-[8px] text-slate-500 capitalize mt-0.5">{m.type}</div>
              </Link>
            ))}
          </div>
        </div>

        {/* AI Signals */}
        <div className="bg-bg-2 border border-white/[.06] rounded-xl p-4">
          <div className="flex justify-between items-center mb-3">
            <div className="flex items-center gap-2"><span className="text-sm font-bold">AI Signals</span><span className="w-1.5 h-1.5 rounded-full bg-emerald-400" style={{animation:'pulse 2s infinite'}} /></div>
            <Link to="/app/scanner" className="text-[10px] text-brand">Scanner →</Link>
          </div>
          <div className="flex flex-col gap-1.5">
            {topSignals.map(s => (
              <Link key={s.id} to={`/app/analyze/${s.symbol}`} className="flex items-center justify-between p-2.5 bg-bg-3 rounded-lg hover:bg-bg-4">
                <div className="flex items-center gap-2">
                  <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${s.action === 'BUY' ? 'bg-emerald-500/10 text-emerald-400' : s.action === 'SELL' ? 'bg-red-500/10 text-red-400' : 'bg-slate-500/10 text-slate-400'}`}>{s.action}</span>
                  <span className="text-[11px] font-bold font-mono">{s.symbol}</span>
                  <span className="text-[8px] text-slate-500 capitalize">{s.asset_type}</span>
                </div>
                <span className="text-[10px] font-bold text-blue-400 font-mono">{s.confidence}%</span>
              </Link>
            ))}
            {topSignals.length === 0 && <div className="text-center text-[10px] text-slate-500 py-6">AI engine warming up...</div>}
          </div>
        </div>
      </div>

      {/* Open Positions preview */}
      {(p.positions || []).length > 0 && (
        <div className="bg-bg-2 border border-white/[.06] rounded-xl overflow-hidden">
          <div className="flex justify-between items-center px-4 py-2.5 border-b border-white/[.04]">
            <span className="text-sm font-bold">Open Positions</span>
            <Link to="/app/portfolio" className="text-[10px] text-brand">Manage →</Link>
          </div>
          <div className="grid grid-cols-7 gap-2 px-4 py-1.5 text-[8px] font-semibold text-slate-500 tracking-widest uppercase border-b border-white/[.04]">
            <span>Asset</span><span>Type</span><span>Side</span><span>Entry</span><span>Current</span><span>P&L</span><span>Value</span>
          </div>
          {(p.positions || []).slice(0, 5).map(pos => (
            <div key={pos.id} className="grid grid-cols-7 gap-2 px-4 py-2.5 border-b border-white/[.02] items-center">
              <span className="text-[11px] font-bold font-mono">{pos.symbol}</span>
              <span className="text-[10px] text-slate-400 capitalize">{pos.asset_type}</span>
              <span className={`text-[8px] font-bold px-1.5 py-0.5 rounded w-fit ${pos.side === 'long' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-red-500/10 text-red-400'}`}>{pos.side.toUpperCase()}</span>
              <span className="text-[10px] text-slate-400 font-mono">${pos.entry_price}</span>
              <span className="text-[10px] text-white font-mono">${(pos.current_price || 0).toLocaleString(undefined, { maximumFractionDigits: 2 })}</span>
              <span className={`text-[10px] font-bold font-mono ${(pos.pnl || 0) >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>{(pos.pnl || 0) >= 0 ? '+' : ''}${(pos.pnl || 0).toFixed(0)}</span>
              <span className="text-[10px] text-white font-mono">${(pos.value || 0).toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
