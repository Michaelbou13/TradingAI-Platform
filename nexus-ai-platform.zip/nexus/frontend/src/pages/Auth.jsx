import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Zap } from 'lucide-react';
import useStore from '../hooks/useStore';

export default function Auth({ mode = 'login' }) {
  const [f, setF] = useState({ name: '', email: '', password: '' });
  const [err, setErr] = useState('');
  const { login, register, loading } = useStore();
  const nav = useNavigate();

  const submit = async e => {
    e.preventDefault(); setErr('');
    try { mode === 'signup' ? await register(f.name, f.email, f.password) : await login(f.email, f.password); nav('/app'); }
    catch (e) { setErr(e.message); }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-bg relative">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_50%_35%_at_50%_50%,rgba(59,130,246,.04),transparent)]" />
      <div className="relative w-[360px] p-6">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-2"><div className="w-7 h-7 bg-brand rounded-lg flex items-center justify-center"><Zap size={14} className="text-white" /></div><span className="text-sm font-extrabold">NEXUS<span className="text-brand">.ai</span></span></div>
          <Link to="/" className="text-[10px] text-slate-500">← Back</Link>
        </div>
        <h1 className="text-2xl font-extrabold tracking-tight mb-1">{mode==='login'?'Welcome back':'Create account'}</h1>
        <p className="text-xs text-slate-400 mb-6">{mode==='login'?'Sign in to your dashboard.':'Start your free trial. $100K demo balance.'}</p>
        {err && <div className="p-2 bg-red-500/10 border border-red-500/15 rounded-lg mb-3 text-[11px] text-red-400">{err}</div>}
        <form onSubmit={submit} className="flex flex-col gap-3">
          {mode==='signup'&&<div><label className="text-[10px] text-slate-400 font-semibold block mb-1">NAME</label><input value={f.name} onChange={e=>setF({...f,name:e.target.value})} placeholder="Your name" className="w-full px-3 py-2.5 rounded-lg border border-white/10 bg-bg-3 text-sm text-white" /></div>}
          <div><label className="text-[10px] text-slate-400 font-semibold block mb-1">EMAIL</label><input type="email" value={f.email} onChange={e=>setF({...f,email:e.target.value})} placeholder="you@email.com" className="w-full px-3 py-2.5 rounded-lg border border-white/10 bg-bg-3 text-sm font-mono text-white" /></div>
          <div><label className="text-[10px] text-slate-400 font-semibold block mb-1">PASSWORD</label><input type="password" value={f.password} onChange={e=>setF({...f,password:e.target.value})} placeholder="••••••••" className="w-full px-3 py-2.5 rounded-lg border border-white/10 bg-bg-3 text-sm text-white" /></div>
          <button disabled={loading} className="w-full py-2.5 bg-brand text-white font-bold rounded-lg shadow-lg shadow-brand/25 mt-1 text-sm disabled:opacity-50">{loading?'...':mode==='login'?'Sign In →':'Create Account →'}</button>
        </form>
        <p className="text-[11px] text-slate-500 mt-4">{mode==='login'?'No account? ':'Have an account? '}<Link to={mode==='login'?'/signup':'/login'} className="text-brand font-semibold">{mode==='login'?'Sign up':'Sign in'}</Link></p>
        {mode==='login'&&<p className="text-[9px] text-slate-600 mt-5 pt-3 border-t border-white/[.04]">Demo: <span className="font-mono text-slate-400">demo@nexus.ai</span> / <span className="font-mono text-slate-400">password123</span></p>}
      </div>
    </div>
  );
}
