import { Routes, Route, Navigate } from 'react-router-dom';
import useStore from './hooks/useStore';
import Landing from './pages/Landing';
import Auth from './pages/Auth';
import Shell from './pages/Shell';
import Dashboard from './pages/Dashboard';
import Markets from './pages/Markets';
import AIScanner from './pages/AIScanner';
import AIAnalysis from './pages/AIAnalysis';
import Trade from './pages/Trade';
import Portfolio from './pages/Portfolio';
import History from './pages/History';
import Settings from './pages/Settings';

function Guard({ children }) {
  return useStore(s => s.user) ? children : <Navigate to="/login" replace />;
}

export default function App() {
  const user = useStore(s => s.user);
  return (
    <Routes>
      <Route path="/" element={user ? <Navigate to="/app" replace /> : <Landing />} />
      <Route path="/login" element={user ? <Navigate to="/app" replace /> : <Auth mode="login" />} />
      <Route path="/signup" element={user ? <Navigate to="/app" replace /> : <Auth mode="signup" />} />
      <Route path="/app" element={<Guard><Shell /></Guard>}>
        <Route index element={<Dashboard />} />
        <Route path="markets" element={<Markets />} />
        <Route path="scanner" element={<AIScanner />} />
        <Route path="analyze/:symbol" element={<AIAnalysis />} />
        <Route path="trade" element={<Trade />} />
        <Route path="portfolio" element={<Portfolio />} />
        <Route path="history" element={<History />} />
        <Route path="settings" element={<Settings />} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
