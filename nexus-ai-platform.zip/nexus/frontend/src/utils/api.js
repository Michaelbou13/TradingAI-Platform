import axios from 'axios';
const api = axios.create({ baseURL: '/api', timeout: 15000 });
api.interceptors.request.use(c => { const t = localStorage.getItem('nx_token'); if (t) c.headers.Authorization = `Bearer ${t}`; return c; });
api.interceptors.response.use(r => r, e => { if (e.response?.status === 401) { localStorage.removeItem('nx_token'); localStorage.removeItem('nx_user'); if (!['/','login','/signup'].includes(window.location.pathname)) window.location.href = '/login'; } return Promise.reject(e); });

export const auth = {
  register: d => api.post('/auth/register', d), login: d => api.post('/auth/login', d),
  me: () => api.get('/auth/me'), updateProfile: d => api.put('/auth/profile', d),
};
export const market = {
  prices: p => api.get('/market/prices', { params: p }), price: s => api.get(`/market/price/${s}`),
  chart: (s, i, l) => api.get(`/market/chart/${s}`, { params: { interval: i, limit: l } }),
  overview: () => api.get('/market/overview'),
};
export const ai = {
  signals: p => api.get('/ai/signals', { params: p }), analyze: s => api.get(`/ai/analyze/${s}`),
  scan: p => api.get('/ai/scan', { params: p }), stats: () => api.get('/ai/stats'),
};
export const trade = {
  order: d => api.post('/trade/order', d), orders: () => api.get('/trade/orders'),
  close: id => api.post(`/trade/close/${id}`),
};
export const portfolio = {
  summary: () => api.get('/portfolio'), history: p => api.get('/portfolio/history', { params: p }),
  performance: () => api.get('/portfolio/performance'),
};
export const settings = {
  get: () => api.get('/settings'), update: d => api.put('/settings', d),
  updateRisk: d => api.put('/settings/risk', d),
};
export default api;
