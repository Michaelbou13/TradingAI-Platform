export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: { extend: { colors: { bg: { DEFAULT:'#060810','2':'#0B0E15','3':'#10141C','4':'#161B25','5':'#1C2230' }, brand: { DEFAULT:'#3B82F6', light:'#60A5FA' } }, fontFamily: { sans: ['Inter','system-ui','sans-serif'], mono: ['Fira Code','monospace'] } } },
  plugins: [],
};
