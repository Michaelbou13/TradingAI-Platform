@echo off
title NEXUS.ai
cd /d "%~dp0"
node start.js
pause
